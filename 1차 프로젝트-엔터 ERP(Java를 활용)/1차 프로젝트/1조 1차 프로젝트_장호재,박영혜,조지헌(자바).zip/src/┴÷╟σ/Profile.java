package 지헌;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class Profile {

	private JTextField sql1;
	private JTextField sql2;
	private JTextField albumF;
	private JTextField sql4;
	private JTextField sql3;
	private JTable table_1;
	private JTable table;
	private JTable table_2;

	/**
	 * @wbp.parser.entryPoint
	 */
	public void profile2(proDto dto) { // String id가 1번
		proDao dao = new proDao();

		proDto dto_2 = dao.select(dto.getName());

		ImageIcon sizeIcon = new ImageIcon(dto_2.getName() + ".jpg");
		Image icon = sizeIcon.getImage();
		Image cIcon = icon.getScaledInstance(200, 200, java.awt.Image.SCALE_SMOOTH);
		Image aCover = icon.getScaledInstance(100, 100, java.awt.Image.SCALE_SMOOTH);

		JFrame f = new JFrame();
		f.setTitle("아티스트 진행 프로젝트");
		JLabel img = new JLabel();
		JButton img1 = new JButton();
		f.setSize(700, 700);
		f.getContentPane().setLayout(null);

		JLabel artistsCover = new JLabel("New label");
		artistsCover.setIcon(new ImageIcon(cIcon)); 
		artistsCover.setBounds(29, 45, 197, 262);
		f.getContentPane().add(artistsCover);

		JLabel artistID = new JLabel("ID");
		artistID.setBounds(253, 92, 98, 18);
		f.getContentPane().add(artistID);

		JLabel artistID_1 = new JLabel("아티스트");
		artistID_1.setBounds(253, 55, 98, 18);
		f.getContentPane().add(artistID_1);

		JLabel 앨범 = new JLabel("설명");
		앨범.setBounds(253, 133, 98, 18);
		f.getContentPane().add(앨범);

		JLabel artistID_5 = new JLabel("헤드담당");
		artistID_5.setBounds(253, 283, 98, 18);
		f.getContentPane().add(artistID_5);


		JButton youtube = new JButton("유투브링크");
		youtube.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {
					if (dto_2.getName().equals("zico")) {
						Desktop.getDesktop().browse(new URI("https://youtu.be/UuV2BmJ1p_I"));
					} else if (dto_2.getName().equals("izone")) {
						Desktop.getDesktop().browse(new URI("https://youtu.be/eDEFolvLn0A"));
					} else if (dto_2.getName().equals("iu")) {
						Desktop.getDesktop().browse(new URI("https://youtu.be/D1PvIWdJ8xo"));
					} else if (dto_2.getName().equals("bts")) {
						Desktop.getDesktop().browse(new URI("https://youtu.be/gwMa6gpoE9I"));
					} else {
						Desktop.getDesktop().browse(new URI("https://youtube.com"));
					}
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (URISyntaxException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}

		});
		youtube.setBackground(Color.RED);
		youtube.setBounds(363, 311, 97, 23);
		f.getContentPane().add(youtube);

		sql1 = new JTextField();
		sql1.setBounds(309, 91, 116, 21);
		f.getContentPane().add(sql1);
		sql1.setColumns(10);

		sql2 = new JTextField(dto_2.getName());
		sql2.setColumns(10);
		sql2.setBounds(309, 54, 116, 21);
		f.getContentPane().add(sql2);

		albumF = new JTextField();
		albumF.setColumns(10);
		albumF.setBounds(309, 132, 225, 111);
		f.getContentPane().add(albumF);

		sql4 = new JTextField();
		sql4.setColumns(10);
		sql4.setBounds(309, 280, 116, 21);
		f.getContentPane().add(sql4);

		JLabel artistID_5_2 = new JLabel("장르");
		artistID_5_2.setBounds(253, 252, 98, 18);
		f.getContentPane().add(artistID_5_2);

		sql3 = new JTextField();
		sql3.setColumns(10);
		sql3.setBounds(309, 249, 116, 21);
		f.getContentPane().add(sql3);

		JButton btnNewButton = new JButton("멜론 링크");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if (dto_2.getName().equals("zico")) {
						Desktop.getDesktop().browse(new URI(
								"https://www.melon.com/search/total/index.htm?q=zico&section=&searchGnbYn=Y&kkoSpl=Y&kkoDpType=&linkOrText=T&ipath=srch_form"));
					} else if (dto_2.getName().equals("izone")) {
						Desktop.getDesktop().browse(new URI(
								"https://www.melon.com/search/total/index.htm?q=izone&section=&linkOrText=T&ipath=srch_form"));
					} else if (dto_2.getName().equals("iu")) {
						Desktop.getDesktop().browse(new URI(
								"https://www.melon.com/search/total/index.htm?q=%EC%95%84%EC%9D%B4%EC%9C%A0&section=&searchGnbYn=Y&kkoSpl=Y&kkoDpType=&linkOrText=T&ipath=srch_form"));
					} else if (dto_2.getName().equals("bts")) {
						Desktop.getDesktop().browse(new URI(
								"https://www.melon.com/search/total/index.htm?q=bts&section=&searchGnbYn=Y&kkoSpl=Y&kkoDpType=&linkOrText=T&ipath=srch_form"));
					} else {
						Desktop.getDesktop().browse(new URI("https://www.melon.com/index.htm"));
					}
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (URISyntaxException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				// 멜론링크도 -> 지속적으로 바뀌어야함....;;

			}
		});
		btnNewButton.setBackground(Color.GREEN);
		btnNewButton.setBounds(253, 311, 97, 23);
		f.getContentPane().add(btnNewButton);

		JButton bt1 = new JButton("검색");
		bt1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = sql2.getText(); // 아티스트 이름 입력
				proDto dto = new proDto();  //dto 객체 생성
				dto.setName(name); //dto 객채에 아티스트 이름 정의
				proDao dao = new proDao(); 
				proDto dto2 = dao.select(dto); // db에 이름으로 매칭된 테이블 값들 정의
				if (dto2 != null) { //검색값 null이 아닌 경우, UI 각 창에 입력
					sql1.setText(dto2.getId());
					sql2.setText(dto2.getName());
					sql3.setText(dto2.getGenre());
					sql4.setText(dto2.getEmp_no());
					albumF.setText(dto2.getDescription());

				} else {
					JOptionPane.showMessageDialog(null, "해당 회원 없음.");
				}
			}
		});
		bt1.setBounds(437, 52, 97, 23);
		f.getContentPane().add(bt1);

		JButton btnNewButton_1 = new JButton("입력");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				proDto dto = new proDto();
				proDao dao = new proDao();
				dao.insert(dto);

			}
		});
		btnNewButton_1.setBounds(357, 352, 97, 23);
		f.getContentPane().add(btnNewButton_1);

		JButton btnNewButton_1_1 = new JButton("담당변경");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				proDto dto = new proDto();
				proDao dao = new proDao();
				dao.update(dto);
				JOptionPane.showMessageDialog(null, "수정이 완료되었습니다.");

			}
		});
		btnNewButton_1_1.setBounds(466, 352, 97, 23);
		f.getContentPane().add(btnNewButton_1_1);

		JButton btnNewButton_1_1_1 = new JButton("삭제");
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				proDto dto = new proDto();
				proDao dao = new proDao();
				dao.delete(dto);
			}
		});
		btnNewButton_1_1_1.setBounds(575, 352, 97, 23);
		f.getContentPane().add(btnNewButton_1_1_1);

		JButton btnNewButton_2 = new JButton("확인");
		btnNewButton_2.setBackground(Color.PINK);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = dto.getName();
				ArrayList<proDto> list = dao.selectlist(name);
				Object[] title = { "프로젝트 ID", "가수명", "앨범명", "장르", "사원" };
				Object[][] content = new Object[list.size()][];
				for (int i = 0; i < list.size(); i++) {
					proDto dto = list.get(i);
					Object[] row = new Object[5];
					row[0] = dto.getId();
					row[1] = dto.getName();
					row[2] = dto.getAlbum_title();
					row[3] = dto.getGenre();
					row[4] = dto.getEmp_no();
					content[i] = row;
				}
				table_2 = new JTable(content, title);
				table_2.setBounds(266, 629, 366, -190);
				f.getContentPane().add(table_2);
				JScrollPane scrollPane = new JScrollPane(table_2);
				scrollPane.setBounds(248, 441, 394, 210);
				f.getContentPane().add(scrollPane);

			}
		});
		btnNewButton_2.setBounds(253, 352, 97, 23);
		f.getContentPane().add(btnNewButton_2);

//					
//					ArrayList<proDto> list = dao.selectlist(id);
//					Object[] title = {"프로젝트 ID", "가수명", "앨범명", "장르", "사원번호"};
//					Object[][] content = new Object[list.size()][];
//					for (int i = 0; i < list.size(); i++) {
//						proDto dto = list.get(i);
//						Object[] row = new Object[5];
//						  row[0] = dto.getId();
//	                      row[1] = dto.getName();
//	                      row[2] = dto.getAlbum_title();
//	                      row[3] = dto.getGenre();
//	                      row[4] = dto.getEmp_no();
//	                      content[i] = row;
//				}
//							
//					JPanel panel = new JPanel();
//					panel.setLayout(null);
//					f.getContentPane().add(panel);
//					
//					JTextField tf = new JTextField();
//					tf.setSize(300,200);
//					tf.setLocation(253, 467);
//					panel.add(tf);
//					
//					JTextArea ta = new JTextArea();
//					JScrollPane jsp = new JScrollPane(ta);
//					jsp.setSize(300,300);
//					jsp.setLocation(253,510);
//					f.getContentPane().add(jsp);
//					

//					//	panel.add(btnNewButton_2);
//					btnNewButton_2.addActionListener(new ActionListener() {
//						public void actionPerformed(ActionEvent e) {
//							proDao name = new proDao();
//							for (int i = 0; i < list.size(); i++) {
//								ta.append(list.get(i).toString() + "\n");
//							}
		// ArrayList<proDto> list = new ArrayList();

		f.setVisible(true);
	}
}
