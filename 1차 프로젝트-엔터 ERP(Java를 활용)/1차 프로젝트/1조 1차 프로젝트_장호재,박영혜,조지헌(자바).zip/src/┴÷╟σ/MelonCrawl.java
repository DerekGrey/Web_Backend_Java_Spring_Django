package 지헌;

import java.io.FileWriter;
import java.util.Iterator;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JLabel;

public class MelonCrawl {
	private static JTable table;
	private static JTextField tf;

	/**
	 * @wbp.parser.entryPoint
	 */
	public void crawl() {

		JFrame f = new JFrame();
		f.setTitle("멜론 차트 순위 확인");
		f.setSize(700, 700);
		f.getContentPane().setLayout(null);

		JTextArea ta = new JTextArea();
		ta.setBounds(12, 27, 425, 447);
		f.getContentPane().add(ta);

		JScrollPane scrollPane = new JScrollPane(ta);
		scrollPane.setBounds(55, 91, 521, 511);
		f.getContentPane().add(scrollPane);

		JButton btnNewButton = new JButton("차트추출");
		btnNewButton.setFont(new Font("함초롬돋움", Font.BOLD, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {
					Connection mel = Jsoup.connect("https://www.melon.com/chart/index.htm"); // 웹사이트 연결
					Document meltitle = mel.get(); // 웹사이트 정보 등록 -> meltitle 에 입력
					Elements mellist = meltitle.select(".rank01 span a"); // 노래 디렉토리 크롤링-> mellist 입력
					Elements artists = meltitle.select(".rank02 span a"); // 가수 디렉토리 크롤링-> artists 입력
					Elements albumtitle = meltitle.select(".rank03 a"); // 앨범 디렉토리 크롤링-> albumtitle 입력
					Elements button = meltitle.select(".wrap .cnt");

					FileWriter file = new FileWriter("멜론실시간차트.txt");
					String[] contents = new String[mellist.size()];

					for (int i = 0; i < mellist.size(); i++) { // for문을 통한 mellist.size 인덱스 값 100개 출력
						String a = (1 + i) + "위 : " + mellist.get(i).text();
						String b = (" - " + artists.get(i).text());
						String c = (" // 앨범 : " + albumtitle.get(i).text());
						System.out.println("\n");
						contents[i] = a + b + c ; //1~100위를 각 인덱스에 입력
						file.write(contents[i]+ "\n");	
				
					}
					file.close();
//					
//					for (String s : contents) {
//						String title = (1+i) + "위 : " + mellist.get(i).text() ;
//						String artist = " - " + artists.get(i).text();
//						String album = " // 앨범 : " + albumtitle.get(i).text();	
//						file.write(s + "\n");			
//					}
					file.close(); // 안닫아주면 나중에 서버가 폭파함.

				} catch (Exception o) { //
					o.printStackTrace();
				}

			}
		});
		btnNewButton.setBounds(563, 32, 97, 23);
		f.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("멜론 실시간 차트 1-100");
		lblNewLabel.setBounds(65, 32, 175, 15);
		f.getContentPane().add(lblNewLabel);

		try {
			Connection mel = Jsoup.connect("https://www.melon.com/chart/index.htm"); // 웹사이트 연결
			Document meltitle = mel.get(); // 웹사이트 정보 등록 -> meltitle 에 입력
			Elements mellist = meltitle.select(".rank01 span a"); // 노래 디렉토리 크롤링-> mellist 입력
			Elements artists = meltitle.select(".rank02 span a"); // 가수 디렉토리 크롤링-> artists 입력
			Elements albumtitle = meltitle.select(".rank03 a"); // 앨범 디렉토리 크롤링-> albumtitle 입력
			Elements button = meltitle.select(".wrap .cnt");

			System.out.println("-----------------------"); // 경계선

			for (int i = 0; i < mellist.size(); i++) { // for문을 통한 mellist.size 인덱스 값 100개 출력
				System.out.print((1 + i) + "위 : " + mellist.get(i).text());
				ta.append((1 + i) + "위 : " + mellist.get(i).text());
				System.out.print(" - " + artists.get(i).text());
				ta.append(" - " + artists.get(i).text());
				System.out.println(" // 앨범 : " + albumtitle.get(i).text());
				ta.append(" // 앨범 : " + albumtitle.get(i).text() + "\n");
				System.out.println("\n");

			}

		} catch (Exception e) { //
			e.printStackTrace();
		}
//		
//		FileWriter file = new FileWriter("멜론실시간차트.txt");
//		String title = (1+i) + "위 : " + mellist.get(i).text() ;
//		String artist = " - " + artists.get(i).text();
//		String album = " // 앨범 : " + albumtitle.get(i).text();	

		f.setVisible(true);
	}
}