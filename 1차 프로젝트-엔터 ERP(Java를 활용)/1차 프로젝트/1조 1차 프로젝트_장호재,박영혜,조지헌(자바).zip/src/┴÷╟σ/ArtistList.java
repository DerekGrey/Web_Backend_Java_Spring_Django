package 지헌;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ArtistList {

	/**
	 * @wbp.parser.entryPoint
	 */
	public void artistList() { //소속 아티스트 리스트 목록

		JFrame arList = new JFrame(); //배경 프레임
		JPanel panel = new JPanel(); //아티스트 목록 프레임

		panel.setBackground(Color.white);
		arList.setSize(1170, 770);
		arList.getContentPane().setLayout(null);
		arList.setTitle("소속 아티스트");
		
		JLabel arlistLabel = new JLabel("소속 아티스트");
		arlistLabel.setFont(new Font("함초롬돋움", Font.BOLD, 24));
		arlistLabel.setBounds(26, 16, 364, 64);
		arList.getContentPane().add(arlistLabel);
		panel.setBounds(26, 165, 1101, 574);
		arList.getContentPane().add(panel);
		
		JButton craw = new JButton("멜론 순위 확인"); //멜론 순위 크롤링 버튼
		craw.setForeground(Color.GREEN);
		craw.setBackground(Color.GRAY);
		craw.setFont(new Font("굴림", Font.BOLD, 12));
		craw.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MelonCrawl c = new MelonCrawl();
				c.crawl();
			}
		});
		craw.setBounds(943, 32, 129, 37);
		arList.getContentPane().add(craw);

		//
		proDao dao = new proDao(); // db 연동 dao
		ArrayList<proDto> list = dao.selectAll(); // 

		//소속 아티스트 만을 list에 출력하기 위해, 중복되지 않게 하나의 리스트를 다시 만듦.
		ArrayList<String> resultList = new ArrayList<String>();
           for (int i = 0; i < list.size(); i++) {
               if (!resultList.contains(list.get(i).getName())) {
                   resultList.add(list.get(i).getName());
               }
           }
           System.out.println(resultList.size());           
           System.out.println(resultList);           

		for (int i = 0; i < list.size(); i++) {
			proDto dto = list.get(i);
				if (resultList.contains(dto.getName())) {
					JButton ar1 = new JButton();
					ImageIcon sizeIcon = new ImageIcon(dto.getName() + ".jpg");
					Image icon = sizeIcon.getImage();
					Image cIcon = icon.getScaledInstance(100, 100, java.awt.Image.SCALE_SMOOTH);
					ar1.setIcon(new ImageIcon(cIcon));
					ar1.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							Profile p = new Profile();
							p.profile2(dto);
				}
			});
			panel.add(ar1);
			resultList.remove(dto.getName());
		}
		}

		arList.setVisible(true);
	}	
}
