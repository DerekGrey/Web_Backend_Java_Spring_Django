package Ui관련;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;

import Db관련.ArtistDAOnara1;
import Db관련.ArtistdtoNara1;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class Icl1Company {

	private JTable table;
	private JScrollPane scrollPane;

	/**
	 * @wbp.parser.entryPoint
	 */

	/**
	 * @wbp.parser.entryPoint
	 */

	/**
	 * @wbp.parser.entryPoint
	 */

	public void ic() {
		JFrame f = new JFrame();

		f.setSize(700, 503);

		JButton btnNewButton = new JButton("TOTAL SALES");
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(Color.DARK_GRAY);
		btnNewButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				ArtistDAOnara1 dao = new ArtistDAOnara1();
				ArrayList<ArtistdtoNara1> list = dao.all();
				System.out.println("조회결과 " + list.size());
				Object[] title = { "date", "event", "sales", "salesvat", "etc" };
				Object[][] contents = new Object[list.size()][];
				for (int i = 0; i < list.size(); i++) {
					ArtistdtoNara1 dto = list.get(i);
					Object[] row = new Object[5];
					row[0] = dto.getDate();
					row[1] = dto.getEvent();
					row[2] = dto.getSales();
					row[3] = dto.getSalesvat();
					row[4] = dto.getEtc();
					contents[i] = row;
				}
				table = new JTable(contents, title);
				table.setBorder((Border) new LineBorder(Color.RED, 1));
				table.setFont(new Font("한컴산뜻돋움", Font.BOLD, 25));
				table.setRowHeight(50);
				table.setCellSelectionEnabled(true);
				scrollPane = new JScrollPane(table);
				scrollPane.setViewportBorder((Border) new TitledBorder(null, " ", TitledBorder.LEADING,
						TitledBorder.TOP, null, Color.ORANGE));
				f.getContentPane().add(scrollPane, BorderLayout.CENTER);
				f.setVisible(true);
			}

		});
		btnNewButton.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		f.getContentPane().add(btnNewButton, BorderLayout.NORTH);

		f.setVisible(true);
	}

}
