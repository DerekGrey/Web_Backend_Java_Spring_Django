package Ui관련;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import javax.swing.JTextField;

import Db관련.ArtistDAObts1;
import Db관련.ArtistDAObts2;
import Db관련.ArtistdtoBts1;
import Db관련.ArtistdtoBts2;

import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class At1bts {
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;
	private JTextField t4;
	private JTextField t5;
	private JTextField t10;
	private JTextField t9;
	private JTextField t8;
	private JTextField t7;
	private JTextField t6;

	/**
	 * @wbp.parser.entryPoint
	 */

	/**
	 * @wbp.parser.entryPoint
	 */

	/**
	 * @wbp.parser.entryPoint
	 */

	public void at(String name) {

		JLabel l1 = new JLabel(name);
		l1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 15));
		JFrame f = new JFrame();
		f.setTitle("Revenue Status");
		f.setSize(500, 500);
		f.getContentPane().setLayout(null);

		l1.setBounds(12, 10, 174, 24);
		f.getContentPane().add(l1);

		JLabel lblNewLabel_1 = new JLabel("Date");
		lblNewLabel_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		lblNewLabel_1.setBounds(0, 82, 57, 15);
		f.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_1_1 = new JLabel("event");
		lblNewLabel_1_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(54, 82, 116, 15);
		f.getContentPane().add(lblNewLabel_1_1);

		t1 = new JTextField();
		t1.setBounds(0, 96, 57, 21);
		f.getContentPane().add(t1);
		t1.setColumns(10);

		t2 = new JTextField();
		t2.setBounds(54, 96, 116, 21);
		f.getContentPane().add(t2);
		t2.setColumns(10);

		JLabel lblNewLabel_1_1_1 = new JLabel("Sales");
		lblNewLabel_1_1_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		lblNewLabel_1_1_1.setBounds(171, 82, 83, 15);
		f.getContentPane().add(lblNewLabel_1_1_1);

		JLabel lblNewLabel_1_1_2 = new JLabel("Salesvat");
		lblNewLabel_1_1_2.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		lblNewLabel_1_1_2.setBounds(253, 82, 83, 15);
		f.getContentPane().add(lblNewLabel_1_1_2);

		t3 = new JTextField();
		t3.setBounds(171, 96, 83, 21);
		f.getContentPane().add(t3);
		t3.setColumns(10);

		t4 = new JTextField();
		t4.setColumns(10);
		t4.setBounds(253, 96, 83, 21);
		f.getContentPane().add(t4);

		t5 = new JTextField();
		t5.setColumns(10);
		t5.setBounds(336, 96, 148, 21);
		f.getContentPane().add(t5);

		JLabel lblNewLabel_1_1_2_1 = new JLabel("Etc");
		lblNewLabel_1_1_2_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		lblNewLabel_1_1_2_1.setBounds(336, 82, 148, 15);
		f.getContentPane().add(lblNewLabel_1_1_2_1);

		JLabel lblNewLabel_1_2 = new JLabel("Date");
		lblNewLabel_1_2.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		lblNewLabel_1_2.setBounds(0, 241, 57, 15);
		f.getContentPane().add(lblNewLabel_1_2);

		JLabel lblNewLabel_1_1_3 = new JLabel("reason");
		lblNewLabel_1_1_3.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		lblNewLabel_1_1_3.setBounds(54, 241, 116, 15);
		f.getContentPane().add(lblNewLabel_1_1_3);

		JLabel lblNewLabel_1_1_1_1 = new JLabel("cost");
		lblNewLabel_1_1_1_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		lblNewLabel_1_1_1_1.setBounds(171, 241, 83, 15);
		f.getContentPane().add(lblNewLabel_1_1_1_1);

		JLabel lblNewLabel_1_1_2_2 = new JLabel("costvat");
		lblNewLabel_1_1_2_2.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		lblNewLabel_1_1_2_2.setBounds(253, 241, 83, 15);
		f.getContentPane().add(lblNewLabel_1_1_2_2);

		JLabel lblNewLabel_1_1_2_1_1 = new JLabel("Etc");
		lblNewLabel_1_1_2_1_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		lblNewLabel_1_1_2_1_1.setBounds(336, 241, 148, 15);
		f.getContentPane().add(lblNewLabel_1_1_2_1_1);

		t10 = new JTextField();
		t10.setColumns(10);
		t10.setBounds(336, 255, 148, 21);
		f.getContentPane().add(t10);

		t9 = new JTextField();
		t9.setColumns(10);
		t9.setBounds(253, 255, 83, 21);
		f.getContentPane().add(t9);

		t8 = new JTextField();
		t8.setColumns(10);
		t8.setBounds(171, 255, 83, 21);
		f.getContentPane().add(t8);

		t7 = new JTextField();
		t7.setColumns(10);
		t7.setBounds(54, 255, 116, 21);
		f.getContentPane().add(t7);

		t6 = new JTextField();
		t6.setColumns(10);
		t6.setBounds(0, 255, 57, 21);
		f.getContentPane().add(t6);

		JButton btnNewButton = new JButton("Income");
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setBackground(Color.GRAY);
		btnNewButton.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Icl1bts nara = new Icl1bts();
				nara.ic();

			}
		});
		btnNewButton.setBounds(0, 49, 97, 23);
		f.getContentPane().add(btnNewButton);

		JButton btnCost = new JButton("Cost");
		btnCost.setForeground(Color.BLACK);
		btnCost.setBackground(Color.GRAY);
		btnCost.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnCost.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Icl2bts nara = new Icl2bts();
				nara.ic();
			}
		});
		btnCost.setBounds(0, 208, 97, 23);
		f.getContentPane().add(btnCost);

		JButton b1 = new JButton("enrollment");
		b1.setForeground(Color.BLACK);
		b1.setBackground(Color.GRAY);
		b1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String date = t1.getText();
				String event = t2.getText();
				int sales = Integer.parseInt(t3.getText());
				int salesvat = Integer.parseInt(t4.getText());
				String etc = t5.getText();

				// 1.가방을 만들자.
				ArtistdtoBts1 dto = new ArtistdtoBts1();

				// 2.가방에 넣자.
				dto.setDate(date);
				dto.setEvent(event);
				dto.setSales(sales);
				dto.setSalesvat(salesvat);
				dto.setEtc(etc);

				// 3.전달
				// 4.가방에 꺼내자.
				ArtistDAObts1 db = new ArtistDAObts1();
				db.insert(dto);
				
				t1.setText("");
				t2.setText("");
				t3.setText("");
				t4.setText("");
				t5.setText("");
			}
		});
		b1.setBounds(0, 140, 97, 23);
		f.getContentPane().add(b1);

		JLabel lblNewLabel_2 = new JLabel("<-Click");
		lblNewLabel_2.setFont(new Font("굴림", Font.BOLD, 12));
		lblNewLabel_2.setForeground(Color.RED);
		lblNewLabel_2.setBounds(96, 49, 158, 23);
		f.getContentPane().add(lblNewLabel_2);

		JLabel lblNewLabel_2_1 = new JLabel("<-Click");
		lblNewLabel_2_1.setFont(new Font("굴림", Font.BOLD, 12));
		lblNewLabel_2_1.setForeground(Color.RED);
		lblNewLabel_2_1.setBounds(96, 208, 158, 23);
		f.getContentPane().add(lblNewLabel_2_1);

		JButton b2 = new JButton("look up");
		b2.setForeground(Color.BLACK);
		b2.setBackground(Color.GRAY);
		b2.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String event = t2.getText();
				// 가방을 만들고,
				ArtistdtoBts1 dto = new ArtistdtoBts1();
				// 가방에 넣음.
				dto.setEvent(event);

				// db처리 부품 복사해서 가지고 왔음.
				ArtistDAObts1 dao = new ArtistDAObts1();

				// select기능 선택해서 호출.
				ArtistdtoBts1 dto2 = dao.select(dto);
				// int data = sc.nextInt();

				System.out.println(dto2);

				// null일 가능성 체크
				if (dto2 != null) {
					t1.setText(dto2.getDate());
					t2.setText(dto2.getEvent());
					t3.setText(String.valueOf(dto2.getSales()));
					t4.setText(String.valueOf(dto2.getSalesvat()));
					t5.setText(dto2.getEtc());
					t1.setForeground(Color.red);
					t2.setForeground(Color.red);
				} else {
					JOptionPane.showMessageDialog(null, "검색결과 없습니다.");
				}

			}
		});
		b2.setBounds(109, 140, 97, 23);
		f.getContentPane().add(b2);

		JButton b3 = new JButton("amend");
		b3.setForeground(Color.BLACK);
		b3.setBackground(Color.GRAY);
		b3.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String date = t1.getText();
		 		String event = t2.getText();
		 		int sales = Integer.parseInt(t3.getText());
				int salesvat = Integer.parseInt(t4.getText());
		 		String etc = t5.getText();
		 		ArtistdtoBts1 dto = new ArtistdtoBts1();
		 		dto.setDate(date);
		 		dto.setEvent(event);
		 		dto.setSales(sales);
		 		dto.setSalesvat(salesvat);
		 		dto.setEtc(etc);
		 		
		 		ArtistDAObts1 dao = new ArtistDAObts1();
		 		dao.update(dto);
		 		t1.setText("");
				t2.setText("");
				t3.setText("");
				t4.setText("");
				t5.setText("");
		 		
			}
		});
		b3.setBounds(216, 140, 97, 23);
		f.getContentPane().add(b3);

		JButton btnNewButton_1_2_2 = new JButton("delete");
		btnNewButton_1_2_2.setForeground(Color.BLACK);
		btnNewButton_1_2_2.setBackground(Color.GRAY);
		btnNewButton_1_2_2.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnNewButton_1_2_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String event = t2.getText();
		 	ArtistdtoBts1 dto = new ArtistdtoBts1();
		 		dto.setEvent(event);
		 		
		 		ArtistDAObts1 dao = new ArtistDAObts1();
		 		dao.delete(dto);
		 		t1.setText("");
				t2.setText("");
				t3.setText("");
				t4.setText("");
				t5.setText("");

			}
		});
		btnNewButton_1_2_2.setBounds(325, 140, 97, 23);
		f.getContentPane().add(btnNewButton_1_2_2);

		JButton btnNewButton_1_1 = new JButton("enrollment");
		btnNewButton_1_1.setForeground(Color.BLACK);
		btnNewButton_1_1.setBackground(Color.GRAY);
		btnNewButton_1_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String date = t6.getText();
				String reason = t7.getText();
				int cost = Integer.parseInt(t8.getText());
				int costvat = Integer.parseInt(t9.getText());
				String etc = t10.getText();

				// 1.가방을 만들자.
				ArtistdtoBts2 dto = new ArtistdtoBts2();

				// 2.가방에 넣자.
				dto.setDate(date);
				dto.setReason(reason);
				dto.setCost(cost);
				dto.setCostvat(costvat);
				dto.setEtc(etc);

				// 3.전달
				// 4.가방에 꺼내자.
				ArtistDAObts2 db = new ArtistDAObts2();
				db.insert(dto);
				
				t6.setText("");
				t7.setText("");
				t8.setText("");
				t9.setText("");
				t10.setText("");
			}
		});
		btnNewButton_1_1.setBounds(0, 297, 97, 23);
		f.getContentPane().add(btnNewButton_1_1);

		JButton btnNewButton_1_2_3 = new JButton("look up");
		btnNewButton_1_2_3.setForeground(Color.BLACK);
		btnNewButton_1_2_3.setBackground(Color.GRAY);
		btnNewButton_1_2_3.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnNewButton_1_2_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String reason = t7.getText();
				// 가방을 만들고,
				ArtistdtoBts2 dto = new ArtistdtoBts2();
				// 가방에 넣음.
				dto.setReason(reason);

				// db처리 부품 복사해서 가지고 왔음.
				ArtistDAObts2 dao = new ArtistDAObts2();

				// select기능 선택해서 호출.
				ArtistdtoBts2 dto2= dao.select(dto);
				// int data = sc.nextInt();

				System.out.println(dto2);

				// null일 가능성 체크
				if (dto2 != null) {
					t6.setText(dto2.getDate());
					t7.setText(dto2.getReason());
					t8.setText(String.valueOf(dto2.getCost()));
					t9.setText(String.valueOf(dto2.getCostvat()));
					t10.setText(dto2.getEtc());
					t6.setForeground(Color.red);
					t7.setForeground(Color.red);
				} else {
					JOptionPane.showMessageDialog(null, "검색결과 없습니다.");
				}
			}
		});
		btnNewButton_1_2_3.setBounds(109, 297, 97, 23);
		f.getContentPane().add(btnNewButton_1_2_3);

		JButton btnNewButton_1_2_1_1 = new JButton("amend");
		btnNewButton_1_2_1_1.setForeground(Color.BLACK);
		btnNewButton_1_2_1_1.setBackground(Color.GRAY);
		btnNewButton_1_2_1_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnNewButton_1_2_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String date = t6.getText();
		 		String reason = t7.getText();
		 		int cost = Integer.parseInt(t8.getText());
				int costvat = Integer.parseInt(t9.getText());
		 		String etc = t10.getText();
		 		ArtistdtoBts2 dto = new ArtistdtoBts2();
		 		dto.setDate(date);
		 		dto.setReason(reason);
		 		dto.setCost(cost);
		 		dto.setCostvat(costvat);
		 		dto.setEtc(etc);
		 		
		 		System.out.println(dto.getReason()+"==========");
		 		
		 		ArtistDAObts2 dao = new ArtistDAObts2();
		 		dao.update(dto);
		 		t6.setText("");
				t7.setText("");
				t8.setText("");
				t9.setText("");
				t10.setText("");
			}
		});
		btnNewButton_1_2_1_1.setBounds(216, 297, 97, 23);
		f.getContentPane().add(btnNewButton_1_2_1_1);

		JButton btnNewButton_1_2_2_1 = new JButton("delete");
		btnNewButton_1_2_2_1.setForeground(Color.BLACK);
		btnNewButton_1_2_2_1.setBackground(Color.GRAY);
		btnNewButton_1_2_2_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnNewButton_1_2_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String reason = t7.getText();
			 	ArtistdtoBts2 dto = new ArtistdtoBts2();
			 		dto.setReason(reason);
			 		
			 		ArtistDAObts2 dao = new ArtistDAObts2();
			 		dao.delete(dto);
			 		t6.setText("");
					t7.setText("");
					t8.setText("");
					t9.setText("");
					t10.setText("");
			}
		});
		btnNewButton_1_2_2_1.setBounds(325, 297, 97, 23);
		f.getContentPane().add(btnNewButton_1_2_2_1);

		JButton btnNewButton_2 = new JButton("calculator");
		btnNewButton_2.setForeground(Color.BLACK);
		btnNewButton_2.setBackground(Color.GRAY);
		btnNewButton_2.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MarginCalBts nara = new MarginCalBts();
				nara.mcc();
			}
		});
		btnNewButton_2.setBounds(171, 369, 97, 23);
		f.getContentPane().add(btnNewButton_2);

		f.setVisible(true);
	}
}
