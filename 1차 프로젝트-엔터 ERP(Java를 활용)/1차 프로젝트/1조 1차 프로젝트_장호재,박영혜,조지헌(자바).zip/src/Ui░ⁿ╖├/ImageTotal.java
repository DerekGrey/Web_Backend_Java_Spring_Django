package Ui관련;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.SystemColor;

public class ImageTotal {

	/**
	 * @wbp.parser.entryPoint
	 */
	public void hocall() {
		//이미지 구현창 만들기
		JFrame f = new JFrame();
		f.setSize(1200,700);
		f.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Album inventory");
		btnNewButton.setBackground(Color.GRAY);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Album name = new Album();
				name.main();
			}
		});
		btnNewButton.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		btnNewButton.setBounds(763, 94, 202, 75);
		f.getContentPane().add(btnNewButton);
		
		JButton btnArtist = new JButton("Artist");
		btnArtist.setBackground(Color.GRAY);
		btnArtist.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Artist name = new Artist();
				name.main();
				
			}
		});
		btnArtist.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		btnArtist.setBounds(502, 94, 202, 75);
		f.getContentPane().add(btnArtist);
		
		JButton btnIncomeSheet = new JButton("Income Sheet");
		btnIncomeSheet.setBackground(Color.GRAY);
		btnIncomeSheet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Incomesheet name = new Incomesheet();
				name.main();
			}
		});
		btnIncomeSheet.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		btnIncomeSheet.setBounds(244, 94, 202, 75);
		f.getContentPane().add(btnIncomeSheet);
		
		JLabel lblNewLabel = new JLabel("JPJ Accounting");
		lblNewLabel.setFont(new Font("한컴산뜻돋움", Font.BOLD, 30));
		lblNewLabel.setBounds(176, 23, 234, 42);
		f.getContentPane().add(lblNewLabel);
		
		JLabel pic = new JLabel("");
		pic.setForeground(Color.GRAY);
		pic.setBackground(SystemColor.windowBorder);
		pic.setHorizontalAlignment(SwingConstants.CENTER);
		pic.setIcon(new ImageIcon("E:\\ggheon\\java_project\\projectCombined\\아티스트.png"));
		pic.setBounds(240, 201, 736, 414);
		f.getContentPane().add(pic);
		f.setVisible(true);
	}
}
