package Ui관련;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

import Db관련.AlbumDAObts1;
import Db관련.Albumdtobts1;

import javax.swing.JTable;

public class Ab1m1bts {
	private JTable table;
	protected JScrollPane scrollPane;
	/**
	 * @wbp.parser.entryPoint
	 */
	public void abmm() {
		JFrame f = new JFrame();
        
        f.setSize(700, 503);
        
        JButton btnNewButton = new JButton("TOTAL PRODUCTION");
        btnNewButton.setForeground(Color.WHITE);
        btnNewButton.setBackground(Color.DARK_GRAY);
        btnNewButton.addActionListener(new ActionListener() {

		
			public void actionPerformed(ActionEvent e) {
                AlbumDAObts1 dao = new AlbumDAObts1();
                ArrayList<Albumdtobts1> list = dao.all();
                System.out.println("조회결과 " + list.size());       
                Object[] title = {"date", "title", "productionquantity"};
                Object[][] contents = new Object[list.size()][];
                for (int i = 0; i < list.size(); i++) {
                    Albumdtobts1 dto = list.get(i);
                    Object[] row = new Object[3];
                    row[0] = dto.getDate();
                    row[1] = dto.getTitle();
                    row[2] = dto.getProductionquantity();
                    contents[i] = row;
                }
                table = new JTable(contents, title);    
                table.setBorder((Border) new LineBorder(Color.RED, 1));
                table.setFont(new Font("한컴산뜻돋움", Font.BOLD, 25));
                table.setRowHeight(50);
                table.setCellSelectionEnabled(true);
                scrollPane = new JScrollPane(table);
                scrollPane.setViewportBorder((Border) new TitledBorder(null, " ", TitledBorder.LEADING, TitledBorder.TOP, null, Color.ORANGE));
                f.getContentPane().add(scrollPane, BorderLayout.CENTER);
                f.setVisible(true);
            }

							
        });
        btnNewButton.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
        f.getContentPane().add(btnNewButton, BorderLayout.NORTH);
        
        
        f.setVisible(true);
    }

}


