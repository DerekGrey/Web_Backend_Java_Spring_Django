package Ui관련;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Font;
import javax.swing.JTextField;

import Db관련.InvDaoZico1;
import Db관련.InvDaoZico2;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class InventoryCalZico {
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;
	/**
	 * @wbp.parser.entryPoint
	 */
	public void mcc() {
		JFrame f =new JFrame();
		f.setSize(500,500);
		f.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("0은 아름다운 숫자!");
		lblNewLabel.setFont(new Font("한컴산뜻돋움", Font.BOLD, 18));
		lblNewLabel.setBounds(165, 10, 154, 60);
		f.getContentPane().add(lblNewLabel);
		
		t1 = new JTextField();
		t1.setBounds(224, 129, 187, 40);
		f.getContentPane().add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		t2.setColumns(10);
		t2.setBounds(224, 173, 187, 40);
		f.getContentPane().add(t2);
		
		t3 = new JTextField();
		t3.setColumns(10);
		t3.setBounds(224, 216, 187, 40);
		f.getContentPane().add(t3);
		
		JButton b1 = new JButton("produce");
		b1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		b1.setBackground(Color.GRAY);
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InvDaoZico1 dao = new InvDaoZico1();
				t1.setText(Integer.toString(dao.select()));
				
				
				
				
			}
		});
		b1.setBounds(58, 128, 154, 40);
		f.getContentPane().add(b1);
		
		JButton b2 = new JButton("sales");
		b2.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		b2.setBackground(Color.GRAY);
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InvDaoZico2 dao = new InvDaoZico2();
				t2.setText(Integer.toString(dao.select()));
			}
		});
		b2.setBounds(58, 173, 154, 40);
		f.getContentPane().add(b2);
		
		JButton b3 = new JButton("remaining");
		b3.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		b3.setBackground(Color.GRAY);
		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num1 = Integer.parseInt(t1.getText());
				int num2 = Integer.parseInt(t2.getText());
				t3.setText((num1-num2)+"");
			}
		});
		b3.setBounds(58, 216, 154, 40);
		f.getContentPane().add(b3);
		f.setVisible(true);
		

	}
}
