package Ui관련;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import Db관련.ProfitDAOIzone1;
import Db관련.ProfitDAOIzone2;
import Db관련.ProfitDAOJpj1;
import Db관련.ProfitDAOJpj2;
import Db관련.ProfitDAOTwice1;
import Db관련.ProfitDAOTwice2;
import Db관련.ProfitDAOZico1;
import Db관련.ProfitDAOZico2;
import Db관련.ProfitDAObts1;
import Db관련.ProfitDAObts2;

import java.awt.Color;
import javax.swing.JTextField;

public class Incomesheet {
	private JTextField t1;
	private JTextField t3;
	private JTextField t5;
	private JTextField t7;
	private JTextField t9;
	private JTextField t2;
	private JTextField t4;
	private JTextField t6;
	private JTextField t8;
	private JTextField t10;
	private JTextField t11;
	private JTextField t12;
	private JTextField t13;
	private JTextField t14;
	private JTextField t15;
	private JTextField t16;
	/**
	 * @wbp.parser.entryPoint
	 */
	/**
	 * @wbp.parser.entryPoint
	 */
	public void main() {
		JFrame f = new JFrame();
		f.setTitle("요약손인계산서");
		f.setSize(700, 700);
		f.getContentPane().setLayout(null);
		
		JLabel l1 = new JLabel("Income Sheet");
		l1.setForeground(Color.BLACK);
		l1.setHorizontalAlignment(SwingConstants.CENTER);
		l1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 35));
		l1.setBounds(97, 0, 484, 84);
		f.getContentPane().add(l1);
		
		JButton btnNewButton = new JButton("BTS");
		btnNewButton.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setBackground(Color.GRAY);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProfitDAObts1 dao = new ProfitDAObts1();
				t1.setText(Integer.toString(dao.select()));
				ProfitDAObts2 dao1 = new ProfitDAObts2();
				t2.setText(Integer.toString(dao1.select()));
				int num1 = Integer.parseInt(t1.getText());
				int num2 = Integer.parseInt(t2.getText());
				t12.setText((num1-num2)+"");
				
				
			}
		});
		btnNewButton.setBounds(12, 140, 97, 31);
		f.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Twice");
		btnNewButton_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnNewButton_1.setForeground(Color.BLACK);
		btnNewButton_1.setBackground(Color.GRAY);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProfitDAOTwice1 dao = new ProfitDAOTwice1();
				t3.setText(Integer.toString(dao.select()));
				ProfitDAOTwice2 dao1 = new ProfitDAOTwice2();
				t4.setText(Integer.toString(dao1.select()));
				int num1 = Integer.parseInt(t3.getText());
				int num2 = Integer.parseInt(t4.getText());
				t13.setText((num1-num2)+"");
			}
		});
		btnNewButton_1.setBounds(12, 178, 97, 31);
		f.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Iz one");
		btnNewButton_2.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnNewButton_2.setForeground(Color.BLACK);
		btnNewButton_2.setBackground(Color.GRAY);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProfitDAOIzone1 dao = new ProfitDAOIzone1();
				t5.setText(Integer.toString(dao.select()));
				ProfitDAOIzone2 dao1 = new ProfitDAOIzone2();
				t6.setText(Integer.toString(dao1.select()));
				int num1 = Integer.parseInt(t5.getText());
				int num2 = Integer.parseInt(t6.getText());
				t14.setText((num1-num2)+"");
			}
		});
		btnNewButton_2.setBounds(12, 219, 97, 31);
		f.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Zico");
		btnNewButton_3.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnNewButton_3.setForeground(Color.BLACK);
		btnNewButton_3.setBackground(Color.GRAY);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProfitDAOZico1 dao = new ProfitDAOZico1();
				t7.setText(Integer.toString(dao.select()));
				ProfitDAOZico2 dao1 = new ProfitDAOZico2();
				t8.setText(Integer.toString(dao1.select()));
				int num1 = Integer.parseInt(t7.getText());
				int num2 = Integer.parseInt(t8.getText());
				t15.setText((num1-num2)+"");
			}
		});
		btnNewButton_3.setBounds(12, 260, 97, 31);
		f.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("JPJ company");
		btnNewButton_4.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnNewButton_4.setForeground(Color.BLACK);
		btnNewButton_4.setBackground(Color.GRAY);
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProfitDAOJpj1 dao = new ProfitDAOJpj1();
				t9.setText(Integer.toString(dao.select()));
				ProfitDAOJpj2 dao1 = new ProfitDAOJpj2();
				t10.setText(Integer.toString(dao1.select()));
				int num1 = Integer.parseInt(t9.getText());
				int num2 = Integer.parseInt(t10.getText());
				t16.setText((num1-num2)+"");
			}
		});
		btnNewButton_4.setBounds(12, 301, 117, 31);
		f.getContentPane().add(btnNewButton_4);
		
		t1 = new JTextField();
		t1.setBounds(141, 140, 168, 29);
		f.getContentPane().add(t1);
		t1.setColumns(10);
		
		t3 = new JTextField();
		t3.setColumns(10);
		t3.setBounds(141, 180, 168, 29);
		f.getContentPane().add(t3);
		
		t5 = new JTextField();
		t5.setColumns(10);
		t5.setBounds(141, 221, 168, 29);
		f.getContentPane().add(t5);
		
		t7 = new JTextField();
		t7.setColumns(10);
		t7.setBounds(141, 262, 168, 29);
		f.getContentPane().add(t7);
		
		t9 = new JTextField();
		t9.setColumns(10);
		t9.setBounds(141, 303, 168, 29);
		f.getContentPane().add(t9);
		
		t2 = new JTextField();
		t2.setColumns(10);
		t2.setBounds(321, 140, 159, 29);
		f.getContentPane().add(t2);
		
		t4 = new JTextField();
		t4.setColumns(10);
		t4.setBounds(321, 180, 159, 29);
		f.getContentPane().add(t4);
		
		t6 = new JTextField();
		t6.setColumns(10);
		t6.setBounds(321, 221, 159, 29);
		f.getContentPane().add(t6);
		
		t8 = new JTextField();
		t8.setColumns(10);
		t8.setBounds(321, 262, 159, 29);
		f.getContentPane().add(t8);
		
		t10 = new JTextField();
		t10.setColumns(10);
		t10.setBounds(321, 303, 159, 29);
		f.getContentPane().add(t10);
		
		JLabel lblNewLabel_1 = new JLabel("수익");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		lblNewLabel_1.setBounds(177, 94, 88, 29);
		f.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("비용");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		lblNewLabel_1_1.setBounds(348, 94, 88, 29);
		f.getContentPane().add(lblNewLabel_1_1);
		
		t11 = new JTextField();
		t11.setColumns(10);
		t11.setBounds(253, 344, 217, 29);
		f.getContentPane().add(t11);
		
		JButton btnNewButton_4_1 = new JButton("이익");
		btnNewButton_4_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num1 = Integer.parseInt(t1.getText());
				int num2 = Integer.parseInt(t2.getText());
				int num3 = Integer.parseInt(t3.getText());
				int num4 = Integer.parseInt(t4.getText());
				int num5 = Integer.parseInt(t5.getText());
				int num6 = Integer.parseInt(t6.getText());
				int num7 = Integer.parseInt(t7.getText());
				int num8 = Integer.parseInt(t8.getText());
				int num9 = Integer.parseInt(t9.getText());
				int num10 = Integer.parseInt(t10.getText());
				t11.setText((num1+num3+num5+num7+num9-num2-num4-num6-num8-num10)+"");
				
			}
		});
		btnNewButton_4_1.setForeground(Color.BLACK);
		btnNewButton_4_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnNewButton_4_1.setBackground(Color.GRAY);
		btnNewButton_4_1.setBounds(12, 347, 97, 31);
		f.getContentPane().add(btnNewButton_4_1);
		
		JLabel l2 = new JLabel("비용은 앨범제조원가등의 제조비와 판관비 명목이 합산되는 개념으로 구현한 정보임에 유의 할 것.");
		l2.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		l2.setVerticalAlignment(SwingConstants.TOP);
		l2.setBounds(12, 388, 660, 23);
		f.getContentPane().add(l2);
		
		t12 = new JTextField();
		t12.setColumns(10);
		t12.setBounds(492, 140, 159, 29);
		f.getContentPane().add(t12);
		
		t13 = new JTextField();
		t13.setColumns(10);
		t13.setBounds(492, 180, 159, 29);
		f.getContentPane().add(t13);
		
		t14 = new JTextField();
		t14.setColumns(10);
		t14.setBounds(492, 221, 159, 29);
		f.getContentPane().add(t14);
		
		t15 = new JTextField();
		t15.setColumns(10);
		t15.setBounds(492, 262, 159, 29);
		f.getContentPane().add(t15);
		
		t16 = new JTextField();
		t16.setColumns(10);
		t16.setBounds(492, 303, 159, 29);
		f.getContentPane().add(t16);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("이익");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		lblNewLabel_1_1_1.setBounds(523, 94, 88, 29);
		f.getContentPane().add(lblNewLabel_1_1_1);
		
		
		
		
		
		
		f.setVisible(true);
	
	
	}
}
