package Ui관련;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;

import Db관련.ProfitDAOZico1;
import Db관련.ProfitDAOZico2;

import javax.swing.SwingConstants;
import java.awt.Color;

public class MarginCalZico {
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;
	/**
	 * @wbp.parser.entryPoint
	 */
	public void mcc() {
		JFrame f =new JFrame();
		f.setSize(500,500);
		f.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Summary Income Seet");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("한컴산뜻돋움", Font.BOLD, 23));
		lblNewLabel.setBounds(106, 10, 255, 71);
		f.getContentPane().add(lblNewLabel);
		
		t1 = new JTextField();
		t1.setBounds(219, 122, 187, 40);
		f.getContentPane().add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		t2.setColumns(10);
		t2.setBounds(219, 172, 187, 40);
		f.getContentPane().add(t2);
		
		t3 = new JTextField();
		t3.setColumns(10);
		t3.setBounds(219, 223, 187, 40);
		f.getContentPane().add(t3);
		
		JButton b1 = new JButton("Sales");
		b1.setBackground(Color.GRAY);
		b1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 15));
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProfitDAOZico1 dao = new ProfitDAOZico1();
				t1.setText(Integer.toString(dao.select()));
				
				
				
				
			}
		});
		b1.setBounds(53, 122, 154, 40);
		f.getContentPane().add(b1);
		
		JButton b2 = new JButton("Cost");
		b2.setBackground(Color.GRAY);
		b2.setFont(new Font("한컴산뜻돋움", Font.BOLD, 15));
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProfitDAOZico2 dao = new ProfitDAOZico2();
				t2.setText(Integer.toString(dao.select()));
			}
		});
		b2.setBounds(53, 172, 154, 40);
		f.getContentPane().add(b2);
		
		JButton b3 = new JButton("Profit");
		b3.setBackground(Color.GRAY);
		b3.setFont(new Font("한컴산뜻돋움", Font.BOLD, 15));
		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num1 = Integer.parseInt(t1.getText());
				int num2 = Integer.parseInt(t2.getText());
				t3.setText((num1-num2)+"");
			}
		});
		b3.setBounds(53, 222, 154, 40);
		f.getContentPane().add(b3);
		f.setVisible(true);
		

	}
}