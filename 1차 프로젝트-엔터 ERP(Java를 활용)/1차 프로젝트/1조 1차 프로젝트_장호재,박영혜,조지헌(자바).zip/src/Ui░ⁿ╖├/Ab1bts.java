package Ui관련;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import Db관련.AlbumDAObts1;
import Db관련.AlbumDAObts2;
import Db관련.Albumdtobts1;
import Db관련.Albumdtobts2;

import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.SwingConstants;

public class Ab1bts {
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;
	private JTextField t4;
	private JTextField t5;
	private JTextField t6;

	/**
	 * @wbp.parser.entryPoint
	 */

	/**
	 * @wbp.parser.entryPoint
	 */

	/**
	 * @wbp.parser.entryPoint
	 */

	public void p1(String name) {

		JLabel l1 = new JLabel(name);
		JFrame f = new JFrame();
		f.setTitle("Revenue Status");
		f.setSize(500, 500);
		f.getContentPane().setLayout(null);

		l1.setBounds(12, 10, 174, 24);
		f.getContentPane().add(l1);

		JButton Album = new JButton("Produce(제작)");
		Album.setBackground(Color.GRAY);
		Album.setHorizontalAlignment(SwingConstants.LEFT);
		Album.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		Album.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Ab1m1bts nara = new Ab1m1bts();
				nara.abmm();

			}
		});
		Album.setBounds(0, 49, 117, 23);
		f.getContentPane().add(Album);

		JLabel lblNewLabel_2 = new JLabel("<-Click");
		lblNewLabel_2.setFont(new Font("굴림", Font.BOLD, 12));
		lblNewLabel_2.setForeground(Color.RED);
		lblNewLabel_2.setBounds(118, 48, 158, 23);
		f.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel = new JLabel("Date");
		lblNewLabel.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		lblNewLabel.setBounds(0, 98, 79, 24);
		f.getContentPane().add(lblNewLabel);
		
		JLabel lblTitle = new JLabel("Title");
		lblTitle.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		lblTitle.setBounds(80, 98, 94, 24);
		f.getContentPane().add(lblTitle);
		
		JLabel lblQuantaty = new JLabel("Prodution quantity");
		lblQuantaty.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		lblQuantaty.setBounds(176, 98, 117, 24);
		f.getContentPane().add(lblQuantaty);
		
		t1 = new JTextField();
		t1.setBounds(0, 121, 79, 29);
		f.getContentPane().add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		t2.setColumns(10);
		t2.setBounds(80, 121, 94, 29);
		f.getContentPane().add(t2);
		
		t3 = new JTextField();
		t3.setColumns(10);
		t3.setBounds(175, 121, 118, 29);
		f.getContentPane().add(t3);
		
		JButton btnNewButton = new JButton("enrollment");
		btnNewButton.setBackground(Color.GRAY);
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String date = t1.getText();
				String title = t2.getText();
				int productionquantity = Integer.parseInt(t3.getText());

				// 1.가방을 만들자.
				Albumdtobts1 dto = new Albumdtobts1();

				// 2.가방에 넣자.
				dto.setDate(date);
				dto.setTitle(title);
				dto.setProductionquantity(productionquantity);
				// 3.전달
				// 4.가방에 꺼내자.
				AlbumDAObts1 db = new AlbumDAObts1();
				db.insert(dto);
				
				t1.setText("");
				t2.setText("");
				t3.setText("");
			}
		});
		btnNewButton.setBounds(0, 169, 97, 29);
		f.getContentPane().add(btnNewButton);
		
		JButton btnLookUp = new JButton("look up");
		btnLookUp.setBackground(Color.GRAY);
		btnLookUp.setForeground(Color.BLACK);
		btnLookUp.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnLookUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String title = t2.getText();
				// 가방을 만들고,
				Albumdtobts1 dto = new Albumdtobts1();
				// 가방에 넣음.
				dto.setTitle(title);

				// db처리 부품 복사해서 가지고 왔음.
				AlbumDAObts1 dao = new AlbumDAObts1();

				// select기능 선택해서 호출.
				Albumdtobts1 dto2 = dao.select(dto);
				// int data = sc.nextInt();

				System.out.println(dto2);

				// null일 가능성 체크
				if (dto2 != null) {
					t1.setText(dto2.getDate());
					t2.setText(dto2.getTitle());
					t3.setText(String.valueOf(dto2.getProductionquantity()));
					t1.setForeground(Color.red);
					t2.setForeground(Color.red);
				} else {
					JOptionPane.showMessageDialog(null, "검색결과 없습니다.");
				}
			}
		});
		btnLookUp.setBounds(107, 169, 97, 29);
		f.getContentPane().add(btnLookUp);
		
		JButton btnAmend = new JButton("amend");
		btnAmend.setBackground(Color.GRAY);
		btnAmend.setForeground(Color.BLACK);
		btnAmend.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnAmend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String date = t1.getText();
		 		String title = t2.getText();
		 		int productionquantity = Integer.parseInt(t3.getText());
		 		Albumdtobts1 dto = new Albumdtobts1();
		 		dto.setDate(date);
		 		dto.setTitle(title);
		 		dto.setProductionquantity(productionquantity);
		 		
		 		AlbumDAObts1 dao = new AlbumDAObts1();
		 		dao.update(dto);
		 		t1.setText("");
				t2.setText("");
				t3.setText("");
			}
		});
		btnAmend.setBounds(211, 169, 97, 29);
		f.getContentPane().add(btnAmend);
		
		JButton btnNewButton_1_1 = new JButton("delete");
		btnNewButton_1_1.setBackground(Color.GRAY);
		btnNewButton_1_1.setForeground(Color.BLACK);
		btnNewButton_1_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String title = t2.getText();
			 	Albumdtobts1 dto = new Albumdtobts1();
			 		dto.setTitle(title);
			 		
			 		AlbumDAObts1 dao = new AlbumDAObts1();
			 		dao.delete(dto);
			 		t1.setText("");
					t2.setText("");
					t3.setText("");

			}
		});
		btnNewButton_1_1.setBounds(318, 169, 97, 29);
		f.getContentPane().add(btnNewButton_1_1);
		
		JLabel lblNewLabel_1 = new JLabel("Date");
		lblNewLabel_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		lblNewLabel_1.setBounds(0, 272, 79, 24);
		f.getContentPane().add(lblNewLabel_1);
		
		JLabel lblTitle_1 = new JLabel("Title");
		lblTitle_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		lblTitle_1.setBounds(80, 272, 94, 24);
		f.getContentPane().add(lblTitle_1);
		
		JLabel lblQuantaty_1 = new JLabel("Sales quantity");
		lblQuantaty_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		lblQuantaty_1.setBounds(176, 272, 117, 24);
		f.getContentPane().add(lblQuantaty_1);
		
		t4 = new JTextField();
		t4.setColumns(10);
		t4.setBounds(0, 295, 79, 29);
		f.getContentPane().add(t4);
		
		t5 = new JTextField();
		t5.setColumns(10);
		t5.setBounds(80, 295, 94, 29);
		f.getContentPane().add(t5);
		
		t6 = new JTextField();
		t6.setColumns(10);
		t6.setBounds(175, 295, 118, 29);
		f.getContentPane().add(t6);
		
		JButton btnNewButton_1 = new JButton("enrollment");
		btnNewButton_1.setBackground(Color.GRAY);
		btnNewButton_1.setForeground(Color.BLACK);
		btnNewButton_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String date = t4.getText();
				String title = t5.getText();
				int salesquantity = Integer.parseInt(t6.getText());

				// 1.가방을 만들자.
				Albumdtobts2 dto = new Albumdtobts2();

				// 2.가방에 넣자.
				dto.setDate(date);
				dto.setTitle(title);
				dto.setSalesquantity(salesquantity);

				// 3.전달
				// 4.가방에 꺼내자.
				AlbumDAObts2 db = new AlbumDAObts2();
				db.insert(dto);
				
				t4.setText("");
				t5.setText("");
				t6.setText("");
			}
		});
		btnNewButton_1.setBounds(0, 343, 97, 29);
		f.getContentPane().add(btnNewButton_1);
		
		JButton btnLookUp_1 = new JButton("look up");
		btnLookUp_1.setBackground(Color.GRAY);
		btnLookUp_1.setForeground(Color.BLACK);
		btnLookUp_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnLookUp_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String title = t5.getText();
				// 가방을 만들고,
				Albumdtobts2 dto = new Albumdtobts2();
				// 가방에 넣음.
				dto.setTitle(title);

				// db처리 부품 복사해서 가지고 왔음.
				AlbumDAObts2 dao = new AlbumDAObts2();

				// select기능 선택해서 호출.
				Albumdtobts2 dto2= dao.select(dto);
				// int data = sc.nextInt();

				System.out.println(dto2);

				// null일 가능성 체크
				if (dto2 != null) {
					t4.setText(dto2.getDate());
					t5.setText(dto2.getTitle());
					t6.setText(String.valueOf(dto2.getSalesquantity()));
					t4.setForeground(Color.red);
					t5.setForeground(Color.red);
				} else {
					JOptionPane.showMessageDialog(null, "검색결과 없습니다.");
				}
			}
		});
		btnLookUp_1.setBounds(107, 343, 97, 29);
		f.getContentPane().add(btnLookUp_1);
		
		JButton btnAmend_1 = new JButton("amend");
		btnAmend_1.setBackground(Color.GRAY);
		btnAmend_1.setForeground(Color.BLACK);
		btnAmend_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnAmend_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String date = t4.getText();
		 		String title = t5.getText();
		 		int salesquantity = Integer.parseInt(t6.getText());
		 		Albumdtobts2 dto = new Albumdtobts2();
		 		dto.setDate(date);
		 		dto.setTitle(title);
		 		dto.setSalesquantity(salesquantity);
		 		
		 		System.out.println(dto.getTitle()+"==========");
		 		
		 		AlbumDAObts2 dao = new AlbumDAObts2();
		 		dao.update(dto);
		 		t4.setText("");
				t5.setText("");
				t6.setText("");
			}
		});
		btnAmend_1.setBounds(211, 343, 97, 29);
		f.getContentPane().add(btnAmend_1);
		
		JButton btnNewButton_1_1_1 = new JButton("delete");
		btnNewButton_1_1_1.setBackground(Color.GRAY);
		btnNewButton_1_1_1.setForeground(Color.BLACK);
		btnNewButton_1_1_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String title = t4.getText();
			 	Albumdtobts2 dto = new Albumdtobts2();
			 		dto.setTitle(title);
			 		
			 		AlbumDAObts2 dao = new AlbumDAObts2();
			 		dao.delete(dto);
			 		t4.setText("");
					t5.setText("");
					t6.setText("");
			}
		});
		btnNewButton_1_1_1.setBounds(318, 343, 97, 29);
		f.getContentPane().add(btnNewButton_1_1_1);
		
		JButton Album_1 = new JButton("Sales(판매)");
		Album_1.setBackground(Color.GRAY);
		Album_1.setHorizontalAlignment(SwingConstants.LEFT);
		Album_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		Album_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Ab1m2bts nara = new Ab1m2bts();
				nara.abmm();
			}
		});
		Album_1.setBounds(0, 223, 117, 23);
		f.getContentPane().add(Album_1);
		
		JLabel lblNewLabel_2_1 = new JLabel("<-Click");
		lblNewLabel_2_1.setFont(new Font("굴림", Font.BOLD, 12));
		lblNewLabel_2_1.setForeground(Color.RED);
		lblNewLabel_2_1.setBounds(118, 222, 158, 23);
		f.getContentPane().add(lblNewLabel_2_1);
		
		JButton Album_2 = new JButton("calculator");
		Album_2.setForeground(Color.BLACK);
		Album_2.setBackground(Color.GRAY);
		Album_2.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		Album_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InventoryCalBts nara = new InventoryCalBts();
				nara.mcc();
			}
		});
		Album_2.setBounds(170, 397, 97, 23);
		f.getContentPane().add(Album_2);

		f.setVisible(true);
	}
}
