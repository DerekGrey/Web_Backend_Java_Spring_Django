package Ui관련;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class Album {
	JLabel l1 = new JLabel("방탄소년단");
	JLabel l2 = new JLabel("트와이스");
	JLabel l3 = new JLabel("아이즈원");
	JLabel l4 = new JLabel("지코");
	JLabel l5 = new JLabel("발매예정신인");
	static String name;

	/**
	 * @wbp.parser.entryPoint
	 */
	public void main() {
//		사내 프로그램에 등록될 아티스별로 수익비용을 확인할수 있다
//		프레임을 구현하는데 나오는 버튼수는 아티스트 수만큼 넣을 예정		
//		아티스트 버튼을 누르면 아티스트별 창이 팝업처럼 뜨면서 db에 등록된내용 확인가능
//		
		JFrame f = new JFrame();
		f.setTitle("앨범판매재고현황");
		f.setSize(626, 615);
		f.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("Album Inventory");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("한컴산뜻돋움", Font.PLAIN, 30));
		lblNewLabel.setBounds(12, 29, 591, 47);
		f.getContentPane().add(lblNewLabel);

		JButton b1 = new JButton("방탄소년단");
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon 변경할아이콘 = new ImageIcon("방탄.png");
				Image 변경할이미지 = 변경할아이콘.getImage(); // ImageIcon을 Image로 변환.
				Image 변경된이미지 = 변경할이미지.getScaledInstance(100, 100, java.awt.Image.SCALE_SMOOTH);
				@SuppressWarnings("unused")
				ImageIcon 변경된아이콘 = new ImageIcon(변경된이미지); // Image로 ImageIcon 생성

				Ab1bts nara = new Ab1bts();
				name = "방탄소년단";
				nara.p1(name);

			}
		});
		b1.setIcon(new ImageIcon("E:\\ggheon\\java_project\\projectCombined\\방탄.PNG"));
		b1.setBounds(12, 86, 188, 147);
		f.getContentPane().add(b1);

		JButton b2 = new JButton("트와이스");
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon 변경할아이콘 = new ImageIcon("경리.png");
				Image 변경할이미지 = 변경할아이콘.getImage(); // ImageIcon을 Image로 변환.
				Image 변경된이미지 = 변경할이미지.getScaledInstance(100, 100, java.awt.Image.SCALE_SMOOTH);
				@SuppressWarnings("unused")
				ImageIcon 변경된아이콘 = new ImageIcon(변경된이미지); // Image로 ImageIcon 생성
				Ab1bts nara = new Ab1bts();
				name = "트와이스";
				nara.p1(name);
			}
		});
		b2.setIcon(new ImageIcon("E:\\ggheon\\java_project\\projectCombined\\쯔위.PNG"));
		b2.setBounds(212, 86, 188, 147);
		f.getContentPane().add(b2);

		JButton b3 = new JButton("아이즈원");
		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon 변경할아이콘 = new ImageIcon("김하영.png");
				Image 변경할이미지 = 변경할아이콘.getImage(); // ImageIcon을 Image로 변환.
				Image 변경된이미지 = 변경할이미지.getScaledInstance(100, 100, java.awt.Image.SCALE_SMOOTH);
				@SuppressWarnings("unused")
				ImageIcon 변경된아이콘 = new ImageIcon(변경된이미지); // Image로 ImageIcon 생성
				Ab1bts nara = new Ab1bts();
				name = "아이즈원";
				nara.p1(name);
			}
		});
		b3.setIcon(new ImageIcon("E:\\ggheon\\java_project\\projectCombined\\아이즈원.PNG"));
		b3.setBounds(415, 86, 188, 147);
		f.getContentPane().add(b3);

		JButton b4 = new JButton("지코");
		b4.setIcon(new ImageIcon("E:\\ggheon\\java_project\\projectCombined\\지코.PNG"));
		b4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon 변경할아이콘 = new ImageIcon("장나라.png");
				Image 변경할이미지 = 변경할아이콘.getImage(); // ImageIcon을 Image로 변환.
				Image 변경된이미지 = 변경할이미지.getScaledInstance(100, 100, java.awt.Image.SCALE_SMOOTH);
				@SuppressWarnings("unused")
				ImageIcon 변경된아이콘 = new ImageIcon(변경된이미지); // Image로 ImageIcon 생성
				Ab1bts nara = new Ab1bts();
				name = "지코";
				nara.p1(name);
			}
		});
		b4.setBounds(83, 301, 188, 147);
		f.getContentPane().add(b4);

		JButton b5 = new JButton("발매예정신인");
		b5.setIcon(new ImageIcon("E:\\ggheon\\java_project\\projectCombined\\나라.PNG"));
		b5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				b5.setIcon(new ImageIcon("E:\\hojae\\java_project\\1조프로젝트\\나라.PNG"));
				ImageIcon 변경할아이콘 = new ImageIcon("제니퍼.png");
				Image 변경할이미지 = 변경할아이콘.getImage(); // ImageIcon을 Image로 변환.
				Image 변경된이미지 = 변경할이미지.getScaledInstance(100, 100, java.awt.Image.SCALE_SMOOTH);
				@SuppressWarnings("unused")
				ImageIcon 변경된아이콘 = new ImageIcon(변경된이미지); // Image로 ImageIcon 생성
				Ab1bts nara = new Ab1bts();
				name = "발매예정신인";
				nara.p1(name);

			}
		});
		b5.setBounds(334, 301, 188, 147);
		f.getContentPane().add(b5);
		l1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));

		l1.setHorizontalAlignment(SwingConstants.CENTER);
		l1.setBounds(44, 243, 129, 24);
		f.getContentPane().add(l1);
		l2.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));

		l2.setHorizontalAlignment(SwingConstants.CENTER);
		l2.setBounds(247, 243, 129, 24);
		f.getContentPane().add(l2);
		l3.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));

		l3.setHorizontalAlignment(SwingConstants.CENTER);
		l3.setBounds(443, 243, 129, 24);
		f.getContentPane().add(l3);
		l4.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));

		l4.setHorizontalAlignment(SwingConstants.CENTER);
		l4.setBounds(111, 458, 129, 24);
		f.getContentPane().add(l4);
		l5.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));

		l5.setHorizontalAlignment(SwingConstants.CENTER);
		l5.setBounds(360, 458, 129, 24);
		f.getContentPane().add(l5);

		f.setVisible(true);

	}

}
