package Db관련;

public class ArtistdtoBts2 {
	String date;
	String reason;
	int cost;
	int costvat;
	String etc;
	
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public int getCostvat() {
		return costvat;
	}
	public void setCostvat(int costvat) {
		this.costvat = costvat;
	}
	public String getEtc() {
		return etc;
	}
	public void setEtc(String etc) {
		this.etc = etc;
	}
	@Override
	public String toString() {
		return "ArtistdtoBts2 [date=" + date + ", reason=" + reason + ", cost=" + cost + ", costvat=" + costvat
				+ ", etc=" + etc + "]";
	}
	
	

}
