package Db관련;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class AlbumDAOtwice2 {
	String url = "jdbc:mysql://localhost:3708/1stproject?characterEncoding=utf8&serverTimezone=UTC";
	String user = "root";
	String password = "1234";

	public ArrayList<Albumdtotwice2> all() {
		ArrayList<Albumdtotwice2> list = new ArrayList<>();
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok..");

			// 2) db연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok..");

			// 3) sql문 결정
			String sql = "select * from album2twice";
			PreparedStatement ps = con.prepareStatement(sql);
			System.out.println("3. sql문 결정 ok..");

			// 4) sql문 전송
			ResultSet rs = ps.executeQuery();
			System.out.println("4. sql문 전송 ok..");

			while (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
				System.out.println("검색 결과가 있어요.!!");
				Albumdtotwice2 dto2 = new Albumdtotwice2();
				String date = rs.getString(1);
				String title = rs.getString(2);
				int salesquantity = rs.getInt(3);
				dto2.setDate(date);
				dto2.setTitle(title);
				dto2.setSalesquantity(salesquantity);
				list.add(dto2);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public Albumdtotwice2 select(Albumdtotwice2 dto) {
		System.out.println(dto.getTitle());// 확인창
		Albumdtotwice2 dto2 = null;
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok..");

			// 2) db연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok..");

			// 3) sql문 결정
			String sql = "select * from album2twice where title = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getTitle());
			System.out.println("3. sql문 결정 ok..");

			// 4) sql문 전송
			ResultSet rs = ps.executeQuery();
			System.out.println("4. sql문 전송 ok..");

			if (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
				System.out.println("검색 결과가 있어요.!!");
				dto2 = new Albumdtotwice2();
				String date = rs.getString(1);
				String title = rs.getString(2);
				int salesquantity = rs.getInt(3);
				dto2.setDate(date);
				dto2.setTitle(title);
				dto2.setSalesquantity(salesquantity);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return dto2;
	}

	public void update(Albumdtotwice2 dto) {
		System.out.println("금액내용수정 처리하다.");
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok..");

			// 2) db연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok..");

			// 3) sql문 결정

			String sql = "update album2twice set date=?, salesquantity=?,  where title = ?";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getDate());
			ps.setString(2, dto.getTitle());
			ps.setInt(3, dto.getSalesquantity());

			// 4) sql문 전송
			ps.executeUpdate();
			System.out.println("4. sql문 전송 ok..");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//1. 회원가입
	public void insert(Albumdtotwice2 dto) {
		// 매개변수(파라메터, parameter), 지역변수

		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok..");

			// 2) db연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok..");

			// 3) sql문 결정

			String sql = "insert into album2twice(date, title, salesquantity) values (?, ?, ?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getDate());
			ps.setString(2, dto.getTitle());
			ps.setInt(3, dto.getSalesquantity());

			System.out.println("3. sql문 결정 ok..");

			// 4) sql문 전송
			ps.executeUpdate();
			System.out.println("4. sql문 전송 ok..");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//2. db연결
	public void connect() {
		System.out.println("DB연결 처리하다.");
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok..");

			// 2) db연결
			DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok..");

			// 3) sql문 결정
			// 4) sql문 전송
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//3. 자료삭제

	public int delete(Albumdtotwice2 dto) {
		System.out.println("삭제처리를 하겠다.");
		int result = 0; //회원탈퇴가 안된 경우.
		try {
			//1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok..");
			
			//2) db연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok..");
			
			//3) sql문 결정
			String sql = "delete from album2twice where title = ? ";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getTitle());
			
			System.out.println("3. sql문 결정 ok..");
			
			//4) sql문 전송
			result = ps.executeUpdate();
			System.out.println("삭제 요청 결과는 " + result);
			System.out.println("4. sql문 전송 ok..");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("test");
		return result;
		
	}

}
