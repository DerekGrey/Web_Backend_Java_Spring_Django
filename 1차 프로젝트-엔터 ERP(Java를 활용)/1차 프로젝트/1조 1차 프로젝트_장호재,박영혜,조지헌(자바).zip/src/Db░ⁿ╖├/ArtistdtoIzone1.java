package Db관련;

public class ArtistdtoIzone1 {
	String date;
	String event;
	int sales;
	int salesvat;
	String etc;

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	public int getSales() {
		return sales;
	}


	public void setSales(int sales2) {
		this.sales = sales2;
	}

	public int getSalesvat() {
		return salesvat;
	}

	public void setSalesvat(int salesvat) {
		this.salesvat = salesvat;
	}

	public String getEtc() {
		return etc;
	}

	public void setEtc(String etc) {
		this.etc = etc;
	}

	@Override
	public String toString() {
		return "Artistdto1Izone [date=" + date + ", event=" + event + ", sales=" + sales + ", salesvat=" + salesvat
				+ ", etc=" + etc + "]";
	}

}
