package Db관련;

public class Albumdto2 {
	
	String date;
	String title;
	int salesquantity;
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getSalesquantity() {
		return salesquantity;
	}
	public void setSalesquantity(int salesquantity) {
		this.salesquantity = salesquantity;
	}

}
