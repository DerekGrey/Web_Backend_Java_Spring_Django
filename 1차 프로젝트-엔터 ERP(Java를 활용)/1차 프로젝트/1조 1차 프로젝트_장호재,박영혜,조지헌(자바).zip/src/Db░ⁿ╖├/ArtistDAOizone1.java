package Db관련;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import java.sql.Connection;

public class ArtistDAOizone1 {
	String url = "jdbc:mysql://localhost:3708/1stproject?characterEncoding=utf8&serverTimezone=UTC";
	String user = "root";
	String password = "1234";

	public ArrayList<ArtistdtoIzone1> all() {
		ArrayList<ArtistdtoIzone1> list = new ArrayList<>();
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok..");

			// 2) db연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok..");

			// 3) sql문 결정
			String sql = "select * from artist1izone";
			PreparedStatement ps = con.prepareStatement(sql);
			System.out.println("3. sql문 결정 ok..");

			// 4) sql문 전송
			ResultSet rs = ps.executeQuery();
			System.out.println("4. sql문 전송 ok..");

			while (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
				System.out.println("검색 결과가 있어요.!!");
				ArtistdtoIzone1 dto2 = new ArtistdtoIzone1();
				String date = rs.getString(1);
				String event = rs.getString(2);
				int sales = rs.getInt(3);
				int salesvat = rs.getInt(4);
				String etc = rs.getString(5);
				dto2.setDate(date);
				dto2.setEvent(event);
				dto2.setSales(sales);
				dto2.setSalesvat(salesvat);
				dto2.setEtc(etc);
				list.add(dto2);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public ArtistdtoIzone1 select(ArtistdtoIzone1 dto) {
		System.out.println(dto.getEtc());// 확인창
		ArtistdtoIzone1 dto2 = null;
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok..");

			// 2) db연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok..");

			// 3) sql문 결정
			String sql = "select * from artist1izone where event = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getEvent());
			System.out.println("3. sql문 결정 ok..");

			// 4) sql문 전송
			ResultSet rs = ps.executeQuery();
			System.out.println("4. sql문 전송 ok..");

			if (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
				System.out.println("검색 결과가 있어요.!!");
				dto2 = new ArtistdtoIzone1();
				String date = rs.getString(1);
				String event = rs.getString(2);
				int sales = rs.getInt(3);
				int salesvat = rs.getInt(4);
				String etc = rs.getString(5);
				dto2.setDate(date);
				dto2.setEvent(event);
				dto2.setSales(sales);
				dto2.setSalesvat(salesvat);
				dto2.setEtc(etc);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return dto2;
	}

	public void update(ArtistdtoIzone1 dto) {
		System.out.println("금액내용수정 처리하다.");
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok..");

			// 2) db연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok..");

			// 3) sql문 결정

			String sql = "update artist1izone set date=?,etc=?, sales=?, salesvat=?  where event = ?";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getDate());
			ps.setString(2, dto.getEtc());
			ps.setInt(3, dto.getSales());
			ps.setInt(4, dto.getSalesvat());
			ps.setString(5, dto.getEvent());

			// 4) sql문 전송
			ps.executeUpdate();
			System.out.println("4. sql문 전송 ok..");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//1. 회원가입
	public void insert(ArtistdtoIzone1 dto) {
		// 매개변수(파라메터, parameter), 지역변수

		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok..");

			// 2) db연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok..");

			// 3) sql문 결정

			String sql = "insert into artist1izone(date, event, sales, salesvat, etc) values (?, ?, ?, ?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getDate());
			ps.setString(2, dto.getEvent());
			ps.setInt(3, dto.getSales());
			ps.setInt(4, dto.getSalesvat());
			ps.setString(5, dto.getEtc());

			System.out.println("3. sql문 결정 ok..");

			// 4) sql문 전송
			ps.executeUpdate();
			System.out.println("4. sql문 전송 ok..");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//2. db연결
	public void connect() {
		System.out.println("DB연결 처리하다.");
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok..");

			// 2) db연결
			DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok..");

			// 3) sql문 결정
			// 4) sql문 전송
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//3. 자료삭제

	public int delete(ArtistdtoIzone1 dto) {
		System.out.println("삭제처리를 하겠다.");
		int result = 0; // 회원탈퇴가 안된 경우.
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok..");

			// 2) db연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok..");

			// 3) sql문 결정
			String sql = "delete from artist1izone where etc = ? ";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getEtc());

			System.out.println("3. sql문 결정 ok..");

			// 4) sql문 전송
			result = ps.executeUpdate();
			System.out.println("삭제 요청 결과는 " + result);
			System.out.println("4. sql문 전송 ok..");

		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("test");
		return result;

	}

}
