package Db관련;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class InvDaoZico2 {
	String url = "jdbc:mysql://localhost:3708/1stproject?characterEncoding=utf8&serverTimezone=UTC";
	String user = "root";
	String password = "1234";

	
	public int select() {
		int sum =0;
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok..");

			// 2) db연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok..");

			// 3) sql문 결정
			String sql = "select sum(salesquantity) from album2bts";
			PreparedStatement ps = con.prepareStatement(sql);
			System.out.println("3. sql문 결정 ok..");

			// 4) sql문 전송
			ResultSet rs = ps.executeQuery();
			System.out.println("4. sql문 전송 ok..");

			if (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
				System.out.println("검색 결과가 있어요.!!");
				sum = rs.getInt(1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return sum;

	}
}

	