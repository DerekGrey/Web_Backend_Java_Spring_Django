package Db관련;

public class ArtistdtoZico2 {
	String date;
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public int getCostvat() {
		return costvat;
	}
	public void setCostvat(int costvat) {
		this.costvat = costvat;
	}
	public String getEtc() {
		return etc;
	}
	public void setEtc(String etc) {
		this.etc = etc;
	}
	String reason;
	int cost;
	int costvat;
	String etc;
	
	

}
