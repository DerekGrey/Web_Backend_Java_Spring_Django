package Db관련;

public class Albumdtobts2 {
	String date;
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getSalesquantity() {
		return salesquantity;
	}
	public void setSalesquantity(int salesquantity) {
		this.salesquantity = salesquantity;
	}
	String title;
	int salesquantity;
	@Override
	public String toString() {
		return "Albumdtobts2 [date=" + date + ", title=" + title + ", salesquantity=" + salesquantity + "]";
	}
	
}
