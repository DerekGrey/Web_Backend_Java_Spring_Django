package Db관련;

public class Albumdtozico1 {
String date;
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public int getProductionquantity() {
	return productionquantity;
}
public void setProductionquantity(int productionquantity) {
	this.productionquantity = productionquantity;
}
String title;
int productionquantity;
@Override
public String toString() {
	return "Albumdtobts1 [date=" + date + ", title=" + title + ", productionquantity=" + productionquantity + "]";
}
	
}
