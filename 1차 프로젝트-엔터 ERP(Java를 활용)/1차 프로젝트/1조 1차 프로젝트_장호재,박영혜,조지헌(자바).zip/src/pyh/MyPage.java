package pyh;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.SystemColor;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.awt.event.ActionEvent;


public class MyPage {
	private static JTextField tt1;
	private static JTextField tt8;
	private static JTextField tt7;
	private static JTextField tt4;
	private static JTextField tt3;
	private static JTextField tt2;
	private static JTextField tt5;
	private static JTextField tt6;
	/**
	 * @wbp.parser.entryPoint
	 */
	public void myPage() {
		
		JFrame j = new JFrame();
		j.setTitle("mypage");
		j.setSize(500, 636);
		j.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("마이페이지");
		lblNewLabel.setFont(new Font("한컴산뜻돋움", Font.BOLD, 25));
		lblNewLabel.setBounds(176, 48, 192, 44);
		j.getContentPane().add(lblNewLabel);

		JButton i1 = new JButton("ID");
		i1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		i1.setBounds(44, 139, 126, 35);
		j.getContentPane().add(i1);

		JButton i2 = new JButton("* PW");
		i2.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		i2.setBounds(44, 179, 126, 35);
		j.getContentPane().add(i2);

		JButton i3 = new JButton("* 이름");
		i3.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		i3.setBounds(44, 220, 126, 35);
		j.getContentPane().add(i3);

		JButton i4 = new JButton("* 전화번호");
		i4.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		i4.setBounds(44, 260, 126, 35);
		j.getContentPane().add(i4);

		JButton i5 = new JButton("부서");
		i5.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		i5.setBounds(44, 300, 126, 35);
		j.getContentPane().add(i5);

		JButton i6 = new JButton("직무");
		i6.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		i6.setBounds(44, 341, 126, 35);
		j.getContentPane().add(i6);

		JButton i7 = new JButton("입사일");
		i7.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		i7.setBounds(44, 381, 126, 35);
		j.getContentPane().add(i7);

		JButton i8 = new JButton("사원번호");
		i8.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		i8.setBounds(44, 423, 126, 35);
		j.getContentPane().add(i8);

		// static 변수
		String logid = Login.loginid;

		// 로그인한 아이디와 같은 정보들이 각 텍스트 박스에 뜨게 해야함.
		JpjloginDTO dto = new JpjloginDTO();
		
		// dto에 id 넣기
		dto.setId(logid);

		// 부품복사
		JpjloginDAO dao = new JpjloginDAO();
		
		// select 기능 선택해서 호출
		JpjloginDTO dto2 = dao.select1(dto);
		
		tt1 = new JTextField();
		tt2 = new JTextField();
		tt3 = new JTextField();
		tt4 = new JTextField();
		tt5 = new JTextField();
		tt6 = new JTextField();
		tt7 = new JTextField();
		tt8 = new JTextField();
//		tt1.setText(Login.loginid);
		
		
		// null체크
		if (dto2 != null) {
			tt1.setText(dto2.getId());
			tt2.setText(dto2.getPw());
			tt3.setText(dto2.getName());
			tt4.setText(dto2.getPhone());
			tt5.setText(dto2.getPart());
			tt6.setText(dto2.getJob());
			tt7.setText(dto2.getDate());
			tt8.setText(dto2.getNumber());
			
		} else {
			System.out.println("null");
		}

		JButton save = new JButton("수정");
		save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// 수정버튼 눌렀을 때 내용 수정. jpjloginDTO와 연결
				String id = tt1.getText();
				String pw = tt2.getText();
				String name = tt3.getText();
				String phone = tt4.getText();

				JpjloginDTO dto = new JpjloginDTO();
				dto.setId(id);
				dto.setPw(pw);
				dto.setName(name);
				dto.setPhone(phone);
				
				//dao로 가져오기
				JpjloginDAO dao = new JpjloginDAO();
				int result2 = dao.update(dto);
				if (result2 !=0) {
					JOptionPane.showMessageDialog(null, "회원정보 수정 완료");
					j.dispose();
				} else {

				}
			}
		});
		save.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		save.setBounds(106, 503, 126, 35);
		j.getContentPane().add(save);

		tt1.setBackground(SystemColor.activeCaptionBorder);
		tt1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 15));
		tt1.setBounds(189, 139, 231, 35);
		j.getContentPane().add(tt1);
		tt1.setColumns(10);

		tt8.setBackground(SystemColor.activeCaptionBorder);
		tt8.setFont(new Font("한컴산뜻돋움", Font.BOLD, 15));
		tt8.setColumns(10);
		tt8.setBounds(189, 423, 231, 35);
		j.getContentPane().add(tt8);

		tt7.setBackground(SystemColor.activeCaptionBorder);
		tt7.setFont(new Font("한컴산뜻돋움", Font.BOLD, 15));
		tt7.setColumns(10);
		tt7.setBounds(189, 381, 231, 35);
		j.getContentPane().add(tt7);

		tt4.setFont(new Font("한컴산뜻돋움", Font.BOLD, 15));
		tt4.setColumns(10);
		tt4.setBounds(189, 260, 231, 35);
		j.getContentPane().add(tt4);

		tt3.setFont(new Font("한컴산뜻돋움", Font.BOLD, 15));
		tt3.setColumns(10);
		tt3.setBounds(189, 220, 231, 35);
		j.getContentPane().add(tt3);

		tt2.setFont(new Font("한컴산뜻돋움", Font.BOLD, 15));
		tt2.setColumns(10);
		tt2.setBounds(189, 179, 231, 35);
		j.getContentPane().add(tt2);

		tt5.setFont(new Font("한컴산뜻돋움", Font.BOLD, 15));
		tt5.setColumns(10);
		tt5.setBackground(SystemColor.activeCaptionBorder);
		tt5.setBounds(189, 300, 231, 35);
		j.getContentPane().add(tt5);

		tt6.setFont(new Font("한컴산뜻돋움", Font.BOLD, 15));
		tt6.setColumns(10);
		tt6.setBackground(SystemColor.activeCaptionBorder);
		tt6.setBounds(189, 341, 231, 35);
		j.getContentPane().add(tt6);

		JLabel lblNewLabel_1 = new JLabel("* 수정가능");
		lblNewLabel_1.setBounds(352, 115, 68, 15);
		j.getContentPane().add(lblNewLabel_1);
		
		JButton save_1 = new JButton("탈퇴");
		save_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//탈퇴!!!
				String id = tt1.getText();
				JpjloginDTO dto = new JpjloginDTO();
				dto.setId(id);
				JpjloginDAO dao = new JpjloginDAO ();
				int result3 = dao.delete(dto2);
				//결과받기
				if (result3 != 0) {
					JOptionPane.showMessageDialog(null, "탈퇴가 완료되었습니다");
//					j.dispose();
					System.exit(0);
					
				}
				
				
			}
		});
		save_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		save_1.setBounds(253, 503, 126, 35);
		j.getContentPane().add(save_1);

		j.setVisible(true);
	}
		
}
