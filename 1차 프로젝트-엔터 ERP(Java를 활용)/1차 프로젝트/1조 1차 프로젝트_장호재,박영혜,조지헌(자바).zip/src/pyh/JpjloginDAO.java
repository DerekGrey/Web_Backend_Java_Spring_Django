package pyh;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;

public class JpjloginDAO {

	String url = "jdbc:mysql://localhost:3708/1stproject?characterEncoding=utf8&serverTimezone=UTC";
	String user = "root";
	String password = "1234";

	// 1. 회원가입
	public void insert(JpjloginDTO dto) {
		System.out.println("회원가입을 완료했습니다.");
		try {
			// 1) 커넥터 설정 - 빌드패스로 경로를 잡아줘야함.....프로젝트에 놓고!!!!!!
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ㅇㅋ");

			// 2) DB연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. DB연결 ㅇㅋ");

			// 3) sql문 설정 >>jpjlogin / DB이름 넣어주기...<<
			String sql = "insert into jpjlogin values (?, ?, ?, ?, ?, ?,?,?)"; // DB 의 ?만 1부터 시작함
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			ps.setString(2, dto.getPw());
			ps.setString(3, dto.getName());
			ps.setString(4, dto.getPhone());
			ps.setString(5, dto.getPart());
			ps.setString(6, dto.getJob());
			ps.setString(7, dto.getDate());
			ps.setString(8, dto.getNumber());
			// 4) sql문 전송
			ps.executeUpdate();
			System.out.println("4.sql문 전송 ㅇㅋ");
			JOptionPane.showMessageDialog(null, "회원가입 성공");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}// void

	// 2. 로그인 - mypage에서 사용
	public int select(JpjloginDTO dto) {
		int result = 0; // 없다
		try {
			// 1. 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ㅇㅋ");

			// 2) DB연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. DB연결 ㅇㅋ");

			// 3) sql문 결정
			String sql = "select * from jpjlogin where id = ?  and pw = ? "; // DB 의 ?만 1부터 시작함
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			ps.setString(2, dto.getPw());

			System.out.println("3.sql문 설정 ㅇㅋ");

			// 4) sql문 전송
			ResultSet rs = ps.executeQuery(); // 둘다 맞으면 rs로 옴
			System.out.println("4.sql문 전송 ㅇㅋ");

			// 아이디 있는지 체크
			if (rs.next()) {
				System.out.println("검색결과 있음");
				result = 1;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	//3. 마이페이지
	public JpjloginDTO select1(JpjloginDTO dto) {
		JpjloginDTO dto2 = null;
		try {
			// 1. 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 마이페이지 커넥터 설정 ㅇㅋ");

			// 2) DB연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. DB연결 ㅇㅋ");

			// 3) sql문 결정
			String sql = "select * from jpjlogin where id = ?"; // DB 의 ?만 1부터 시작함
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			System.out.println("3.sql문 설정 ㅇㅋ");

			// 4) sql문 전송
			ResultSet rs = ps.executeQuery(); // 둘다 맞으면 rs로 옴
			System.out.println("4.sql문 전송 ㅇㅋ");

			// 아이디 있는지 체크
			if (rs.next()) {
				System.out.println("마이페이지 검색결과 있음");
				dto2 = new JpjloginDTO();
				String id = rs.getString(1);
				String pw = rs.getString(2);
				String name = rs.getString(3);
				String phone = rs.getString(4);
				String part = rs.getString(5);
				String job = rs.getString(6);
				String date = rs.getString(7);
				String number = rs.getString(8);
				
				//가져온거 mypage에 보내주기
				dto2.setId(id);
				dto2.setPw(pw);
				dto2.setName(name);
				dto2.setPhone(phone);
				dto2.setPart(part);
				dto2.setJob(job);
				dto2.setDate(date);
				dto2.setNumber(number);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return dto2;
	}
	
	
    // 4. 회원수정 - mypage에서 사용
	public int update(JpjloginDTO dto) {
		System.out.println("회원정보수정 합니다.");
		int result2 = 0;
		try {
			// 1. 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ㅇㅋ");

			// 2) DB연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. DB연결 ㅇㅋ");

			// 3) sql문 결정
			String sql = "update jpjlogin set pw = ? , name = ? , phone = ? where id = ? "; 
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getPw());
			ps.setString(2, dto.getName());
			ps.setString(3, dto.getPhone());
			ps.setString(4, dto.getId());
			System.out.println("3.sql문 결정 ㅇㅋ");

//			 4) sql문 전송
			result2 = ps.executeUpdate();
			System.out.println("4.sql문 전송 ㅇㅋ");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result2;
	}
	
	// 5. 회원탈퇴 - mypage에서 사용
	public int delete(JpjloginDTO dto) {
		System.out.println("회원탈퇴 합니다.");
		int result3 = 0;
		try {
			// 1. 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ㅇㅋ");

			// 2) DB연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. DB연결 ㅇㅋ");

			// 3) sql문 결정
			String sql = "delete from jpjlogin where id = ? "; 
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			System.out.println("3.sql문 결정 ㅇㅋ");

//			 4) sql문 전송
			result3 = ps.executeUpdate();
			System.out.println("4.sql문 전송 ㅇㅋ");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result3;
	}
	
	//6. 아이디 중복확인
	public JpjloginDTO select2(JpjloginDTO dto) {
		JpjloginDTO dto3 = null;
		try {
			// 1. 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 마이페이지 커넥터 설정 ㅇㅋ");

			// 2) DB연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. DB연결 ㅇㅋ");

			// 3) sql문 결정
			String sql = "select * from jpjlogin where id = ?"; // DB 의 ?만 1부터 시작함
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			System.out.println("3.sql문 설정 ㅇㅋ");

			// 4) sql문 전송
			ResultSet rs = ps.executeQuery(); 
			System.out.println("4.sql문 전송 ㅇㅋ");

			// 아이디 있는지 체크
			if (rs.next()) {
				System.out.println("검색결과 있음");
				dto3 = new JpjloginDTO();
				String id = rs.getString(1);
				dto3.setId(id);
				System.out.println("중복 된 아이디");
			}else {
				System.out.println("사용 가능한 아이디");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return dto3;
	}
	
	

}// class
