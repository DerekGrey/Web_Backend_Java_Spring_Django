package pyh;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import Ui관련.ImageTotal;

public class Login {
	private static JTextField t1;
	private static JTextField t2;
    static String loginid;

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setTitle("JPJ Ent. 로그인");
		f.getContentPane().setForeground(Color.WHITE);
		f.setSize(1200, 800);
		f.getContentPane().setLayout(null);

		JButton btnNewButton_1_1_1_1_1 = new JButton("대나무 숲");
		btnNewButton_1_1_1_1_1.setBounds(969, 82, 179, 31);
		f.getContentPane().add(btnNewButton_1_1_1_1_1);

		JButton btnNewButton_1_1_1_1_1_1 = new JButton("회계관리");
		btnNewButton_1_1_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnNewButton_1_1_1_1_1_1.setBounds(778, 82, 179, 31);
		f.getContentPane().add(btnNewButton_1_1_1_1_1_1);

		JButton btnNewButton_1_1_1_1_1_1_1_1 = new JButton("아티스트 목록");
		btnNewButton_1_1_1_1_1_1_1_1.setBounds(587, 82, 179, 31);
		f.getContentPane().add(btnNewButton_1_1_1_1_1_1_1_1);

		JLabel lblNewLabel = new JLabel("JPJ Ent. 로그인해주세요");
		lblNewLabel.setFont(new Font("한컴산뜻돋움", Font.BOLD, 30));
		lblNewLabel.setBounds(456, 238, 310, 56);
		f.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("ID");
		lblNewLabel_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 40));
		lblNewLabel_1.setBounds(444, 380, 68, 46);
		f.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_1_1 = new JLabel("PW");
		lblNewLabel_1_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 40));
		lblNewLabel_1_1.setBounds(444, 450, 68, 46);
		f.getContentPane().add(lblNewLabel_1_1);

		t1 = new JTextField();
		t1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		t1.setBounds(557, 380, 244, 46);
		f.getContentPane().add(t1);
		t1.setColumns(10);
		t1.getText();

		t2 = new JTextField();
		t2.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		t2.setColumns(10);
		t2.setBounds(557, 450, 244, 46);
		f.getContentPane().add(t2);
		t2.getText();

		JButton btnNewButton_1 = new JButton("로그인");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (t1.getText().equals("") || t2.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "ID, PW를 확인해주세요.");
				} else {
					String userid = t1.getText();
					String userpw = t2.getText();
					JpjloginDTO dto = new JpjloginDTO();
					// dto에 값 넣기
					dto.setId(userid);
					dto.setPw(userpw);

					// dao로 가져오기
					JpjloginDAO dao = new JpjloginDAO();
					int result = dao.select(dto); // dao에서 처리한 값 넣기
					if (result == 1) {
						JOptionPane.showMessageDialog(null, "환영합니다.");
						loginid = userid; 
						// 팝업메소드 호출
						Main sign = new Main(); 
						sign.signIn();
					} else {
						JOptionPane.showMessageDialog(null, "ID, PW를 확인해주세요. ");
					}
				}
			}
		});
		btnNewButton_1.setBackground(new Color(0, 191, 255));
		btnNewButton_1.setForeground(Color.BLACK);
		btnNewButton_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		btnNewButton_1.setBounds(478, 574, 136, 46);
		f.getContentPane().add(btnNewButton_1);

		JButton btnNewButton_1_1 = new JButton("회원가입");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// 회원가입 눌렀을 때 회원가입창 뜨게 하기
				Join sign = new Join(); // 팝업메소드 호출
				sign.signIn();
			}
		});
		btnNewButton_1_1.setBackground(new Color(0, 191, 255));
		btnNewButton_1_1.setForeground(Color.BLACK);
		btnNewButton_1_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		btnNewButton_1_1.setBounds(651, 574, 136, 46);
		f.getContentPane().add(btnNewButton_1_1);

		JLabel lblNewLabel_3 = new JLabel("jpj Ent.");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel_3.setBounds(115, 30, 136, 46);
		f.getContentPane().add(lblNewLabel_3);

		f.setVisible(true);

	}
}
