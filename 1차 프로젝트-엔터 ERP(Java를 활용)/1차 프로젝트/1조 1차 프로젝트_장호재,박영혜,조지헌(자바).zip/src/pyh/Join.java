package pyh;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextField;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Join {
	private static JTextField t1;
	private static JTextField t2;
	private static JTextField t3;
	private static JTextField t4;
	private static JTextField t7;
	private JTextField t8;

	// 회원가입창이 뜨도록
	/**
	 * @wbp.parser.entryPoint
	 */
	public void signIn() {
		JFrame f = new JFrame();
		f.setTitle("jpj Ent. 임직원 회원가입");
		f.setSize(500, 700);
		f.getContentPane().setLayout(null);

		JButton btnId = new JButton("ID");
		btnId.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		btnId.setBounds(54, 128, 122, 38);
		f.getContentPane().add(btnId);

		t1 = new JTextField();
		t1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		t1.setBounds(196, 128, 151, 38);
		f.getContentPane().add(t1);
		t1.setColumns(10);

		JButton btnPw = new JButton("PW");
		btnPw.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		btnPw.setBounds(54, 176, 122, 38);
		f.getContentPane().add(btnPw);

		t2 = new JTextField();
		t2.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		t2.setColumns(10);
		t2.setBounds(196, 176, 240, 38);
		f.getContentPane().add(t2);

		JButton btnId_1_1 = new JButton("이름");
		btnId_1_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		btnId_1_1.setBounds(54, 225, 122, 38);
		f.getContentPane().add(btnId_1_1);

		t3 = new JTextField();
		t3.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		t3.setColumns(10);
		t3.setBounds(196, 225, 240, 38);
		f.getContentPane().add(t3);

		JButton btnId_1_1_1 = new JButton("전화번호");
		btnId_1_1_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		btnId_1_1_1.setBounds(54, 276, 122, 38);
		f.getContentPane().add(btnId_1_1_1);

		t4 = new JTextField();
		t4.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		t4.setColumns(10);
		t4.setBounds(196, 276, 240, 38);
		f.getContentPane().add(t4);

		JButton btnId_1_1_1_1 = new JButton("부서");
		btnId_1_1_1_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		btnId_1_1_1_1.setBounds(54, 324, 122, 38);
		f.getContentPane().add(btnId_1_1_1_1);

		JButton btnId_1_1_1_1_1 = new JButton("직무");
		btnId_1_1_1_1_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		btnId_1_1_1_1_1.setBounds(54, 372, 122, 38);
		f.getContentPane().add(btnId_1_1_1_1_1);

		JButton btnId_1_1_1_1_1_1 = new JButton("입사일");
		btnId_1_1_1_1_1_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		btnId_1_1_1_1_1_1.setBounds(54, 422, 122, 38);
		f.getContentPane().add(btnId_1_1_1_1_1_1);

		t7 = new JTextField();
		t7.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		t7.setColumns(10);
		t7.setBounds(196, 422, 240, 38);
		f.getContentPane().add(t7);

		// 콤보박스에 내용 넣기 - 부서
		String part[] = { "선택", "Finance", "Management", "Sales", "Marketing" };
		JComboBox t5 = new JComboBox(part);
		t5.setBounds(196, 324, 240, 38);
		f.getContentPane().add(t5);
		
		// 콤보박스에 내용 넣기 - 직무
		String job[] = { "선택", "CEO", "CIO", "CFO", "Intern", "Manager" };
		JComboBox t6 = new JComboBox(job);
		t6.setBounds(196, 372, 240, 38);
		f.getContentPane().add(t6);
		
		

		JLabel lblNewLabel = new JLabel("회 원 가 입");
		lblNewLabel.setFont(new Font("한컴산뜻돋움", Font.BOLD, 25));
		lblNewLabel.setBounds(185, 46, 142, 38);
		f.getContentPane().add(lblNewLabel);
		
		JButton btnId_1_1_1_1_1_1_1 = new JButton("사원번호");
		btnId_1_1_1_1_1_1_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		btnId_1_1_1_1_1_1_1.setBounds(54, 469, 122, 38);
		f.getContentPane().add(btnId_1_1_1_1_1_1_1);
		
		t8 = new JTextField();
		t8.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		t8.setColumns(10);
		t8.setBounds(196, 469, 240, 38);
		f.getContentPane().add(t8);

		JButton btnNewButton_1 = new JButton("가입");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//가입버튼 눌렀을 때, 회원가입처리. DB랑 연결 필요
				String id = t1.getText();
				String pw = t2.getText();
				String name = t3.getText();
				String phone = t4.getText();
				String part = t5.getSelectedItem().toString();
				String job = t6.getSelectedItem().toString();
				String date = t7.getText();
				String number = t8.getText();
				
				//1. 가방을 만들자
				JpjloginDTO dto = new JpjloginDTO();
				
				//2. 가방에 넣자
				dto.setId(id);
				dto.setPw(pw);
				dto.setName(name);
				dto.setPhone(phone);
				dto.setPart(part);
				dto.setJob(job);
				dto.setDate(date);
				dto.setNumber(number);
				
				//3. 이동
				JpjloginDAO db = new JpjloginDAO();
				db.insert(dto);			
				f.dispose();
				
			}
		});
		btnNewButton_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 20));
		btnNewButton_1.setBounds(157, 543, 170, 54);
		f.getContentPane().add(btnNewButton_1);
		
		JButton btnId_1 = new JButton("중복확인");
		btnId_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//중복확인
				String joinid = t1.getText();
				JpjloginDTO dto = new JpjloginDTO();
				dto.setId(joinid);
				
				//dao가져오기
				JpjloginDAO dao = new JpjloginDAO();
				JpjloginDTO dto3 = dao.select2(dto);
				
				
				if (dto3 != null) {
					JOptionPane.showMessageDialog(null, "중복 된 아이디입니다");
				} else {
					JOptionPane.showMessageDialog(null, "사용가능한 아이디입니다");
				} 
			}
		});
		btnId_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 12));
		btnId_1.setBounds(350, 128, 86, 38);
		f.getContentPane().add(btnId_1);

		
		
		
		f.setVisible(true);

	}
}
