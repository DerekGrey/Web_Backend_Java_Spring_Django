package pyh;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import Board.Board;
import Ui관련.ImageTotal;
import 지헌.ArtistList;

import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class Main {
	JLabel time;
	/**
	 * @wbp.parser.entryPoint
	 */
	public void signIn() {
		JFrame f = new JFrame ();
		f.setTitle("JPJ Ent. 로그인");
		f.getContentPane().setForeground(Color.WHITE);
		f.setSize(1200, 800);
		f.getContentPane().setLayout(null);
		
		JButton btnNewButton_1_1_1_1_1 = new JButton("대나무 숲");
		btnNewButton_1_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Board sign = new Board();
				sign.board();
			}
		});
		btnNewButton_1_1_1_1_1.setBounds(969, 82, 179, 31);
		f.getContentPane().add(btnNewButton_1_1_1_1_1);
		
		JButton btnNewButton_1_1_1_1_1_1 = new JButton("회계관리");
		btnNewButton_1_1_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageTotal img = new ImageTotal();
				img.hocall();
			}
		});
		btnNewButton_1_1_1_1_1_1.setBounds(778, 82, 179, 31);
		f.getContentPane().add(btnNewButton_1_1_1_1_1_1);
		
		JButton btnNewButton_1_1_1_1_1_1_1_1 = new JButton("아티스트 목록");
		btnNewButton_1_1_1_1_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ArtistList al = new ArtistList();
				al.artistList();
				
			}
		});
		btnNewButton_1_1_1_1_1_1_1_1.setBounds(587, 82, 179, 31);
		f.getContentPane().add(btnNewButton_1_1_1_1_1_1_1_1);
		
		JLabel lblNewLabel_2 = new JLabel("님 환영합니다.");
		lblNewLabel_2.setBounds(951, 22, 127, 19);
		f.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("jpj Ent.");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel_3.setBounds(115, 30, 136, 46);
		f.getContentPane().add(lblNewLabel_3);
		
		JButton btnNewButton_1_1_1_1_1_1_1_1_1 = new JButton("마이페이지");
		btnNewButton_1_1_1_1_1_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//마이페이지를 눌렀을 때, 마이페이지 창이 뜨도록 설정
				MyPage sign = new MyPage(); //팝업메소드 호출
				sign.myPage();
				
			}
		});
		btnNewButton_1_1_1_1_1_1_1_1_1.setBounds(396, 82, 179, 31);
		f.getContentPane().add(btnNewButton_1_1_1_1_1_1_1_1_1);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setIcon(new ImageIcon("E:\\ggheon\\java_project\\projectCombined\\이미지 006.png"));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(149, 177, 895, 520);
		f.getContentPane().add(btnNewButton);
		
		JButton name = new JButton("");
		name.setBounds(831, 20, 97, 23);
		f.getContentPane().add(name);
		name.setText(Login.loginid);
		
		Calendar cal = Calendar.getInstance();
		time = new JLabel(cal.getTime()+"");
		time.setBounds(831, 51, 300, 19);
		f.getContentPane().add(time);

		Time t = new Time();
		t.start();
		
		f.setVisible(true);
	}
	
	//시간
	public class Time extends Thread {
		@Override
		public void run() {
			for (int i = 0; i < 1000; i++) {
				try {
					Thread.sleep(1000);
				} catch (Exception e) {
				}
				Calendar cal = Calendar.getInstance();
				time.setText(cal.getTime()+"");
			}
		}
	}
	
	
	
}
