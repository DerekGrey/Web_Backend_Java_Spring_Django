-- MySQL dump 10.13  Distrib 5.7.29, for Win64 (x86_64)
--
-- Host: localhost    Database: 1stproject
-- ------------------------------------------------------
-- Server version	5.7.29-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `album`
--

DROP TABLE IF EXISTS `album`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `album` (
  `today_date` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `album_name` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `album_like` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `title_name` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `title_like` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `youtube_streaming` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `releasedate` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `emp_no` varchar(100) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album`
--

LOCK TABLES `album` WRITE;
/*!40000 ALTER TABLE `album` DISABLE KEYS */;
INSERT INTO `album` VALUES ('1','bts','','','','em1',NULL,NULL),('2','twice','','','','em2',NULL,NULL),('3','izone','','','','em3',NULL,NULL),('4','zico','','','','em4',NULL,NULL),('5','nara','','','','em5',NULL,NULL),('20200312','map_of_the_soul_7','116111','on','168366','123300518','20200221','em1'),('20200312','fancy','20287','fancy','115903','273591362','20190422','em2'),('20200312','bloom_iz','26774','fiesta','78152','25268466','20200217','em3'),('20200312','anysong','22231','anysong','208393','30966247','20200113','em4'),('5','nara','','','','','','em5'),('1','11','1','1','1','1','1','1');
/*!40000 ALTER TABLE `album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `album1bts`
--

DROP TABLE IF EXISTS `album1bts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `album1bts` (
  `date` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `productionquantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album1bts`
--

LOCK TABLES `album1bts` WRITE;
/*!40000 ALTER TABLE `album1bts` DISABLE KEYS */;
INSERT INTO `album1bts` VALUES ('20200316','map7',200000),('20200314','map7(20200314)',200000),('20200316','map7-1',200000),('20200314','map7',10000);
/*!40000 ALTER TABLE `album1bts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `album1izone`
--

DROP TABLE IF EXISTS `album1izone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `album1izone` (
  `date` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `productionquantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album1izone`
--

LOCK TABLES `album1izone` WRITE;
/*!40000 ALTER TABLE `album1izone` DISABLE KEYS */;
/*!40000 ALTER TABLE `album1izone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `album1twice`
--

DROP TABLE IF EXISTS `album1twice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `album1twice` (
  `date` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `productionquantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album1twice`
--

LOCK TABLES `album1twice` WRITE;
/*!40000 ALTER TABLE `album1twice` DISABLE KEYS */;
/*!40000 ALTER TABLE `album1twice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `album1zico`
--

DROP TABLE IF EXISTS `album1zico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `album1zico` (
  `date` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `productionquantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album1zico`
--

LOCK TABLES `album1zico` WRITE;
/*!40000 ALTER TABLE `album1zico` DISABLE KEYS */;
/*!40000 ALTER TABLE `album1zico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `album2bts`
--

DROP TABLE IF EXISTS `album2bts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `album2bts` (
  `date` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `salesquantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album2bts`
--

LOCK TABLES `album2bts` WRITE;
/*!40000 ALTER TABLE `album2bts` DISABLE KEYS */;
/*!40000 ALTER TABLE `album2bts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `album2izone`
--

DROP TABLE IF EXISTS `album2izone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `album2izone` (
  `date` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `salesquantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album2izone`
--

LOCK TABLES `album2izone` WRITE;
/*!40000 ALTER TABLE `album2izone` DISABLE KEYS */;
/*!40000 ALTER TABLE `album2izone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `album2twice`
--

DROP TABLE IF EXISTS `album2twice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `album2twice` (
  `date` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `salesquantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album2twice`
--

LOCK TABLES `album2twice` WRITE;
/*!40000 ALTER TABLE `album2twice` DISABLE KEYS */;
/*!40000 ALTER TABLE `album2twice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `album2zico`
--

DROP TABLE IF EXISTS `album2zico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `album2zico` (
  `date` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `salesquantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album2zico`
--

LOCK TABLES `album2zico` WRITE;
/*!40000 ALTER TABLE `album2zico` DISABLE KEYS */;
/*!40000 ALTER TABLE `album2zico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artist`
--

DROP TABLE IF EXISTS `artist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artist` (
  `id` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `genre` varchar(100) DEFAULT NULL,
  `emp_no` varchar(100) DEFAULT NULL,
  `album_title` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artist`
--

LOCK TABLES `artist` WRITE;
/*!40000 ALTER TABLE `artist` DISABLE KEYS */;
INSERT INTO `artist` VALUES ('1','izone','dance','CJENM','bloom_iz','12명으로 구성된 팀'),('1','kwonnara','null','호재','이태원클래스','권나라'),('1','twice','dance','JYP','Feel Special','JYP네 아이돌'),('1','iu','kpop','아이유팀','blueming','갓이유'),('1','zico','hiphop','KOZ','아무노래','지 지 지 지아코'),('1','jangbumjun','rock','아무개','벚꽃연금','벚꽃연금 is coming'),('1','bts','dance','방시혁','map_of_the_soul7','World best'),('2','twice','kpop','JYP','Fancy','jyp\'s childs'),('2','izone','fiesta','지헌','Heart*iz','CJ ENM'),('3','izone','댄스','인턴','라비앙로즈',NULL);
/*!40000 ALTER TABLE `artist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artist1bts`
--

DROP TABLE IF EXISTS `artist1bts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artist1bts` (
  `date` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `event` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `sales` int(11) DEFAULT NULL,
  `salesvat` int(11) DEFAULT NULL,
  `etc` varchar(100) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artist1bts`
--

LOCK TABLES `artist1bts` WRITE;
/*!40000 ALTER TABLE `artist1bts` DISABLE KEYS */;
INSERT INTO `artist1bts` VALUES ('1','1',2,1,'1');
/*!40000 ALTER TABLE `artist1bts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artist1izone`
--

DROP TABLE IF EXISTS `artist1izone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artist1izone` (
  `date` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `event` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `sales` int(11) DEFAULT NULL,
  `salesvat` int(11) DEFAULT NULL,
  `etc` varchar(100) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artist1izone`
--

LOCK TABLES `artist1izone` WRITE;
/*!40000 ALTER TABLE `artist1izone` DISABLE KEYS */;
/*!40000 ALTER TABLE `artist1izone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artist1nara`
--

DROP TABLE IF EXISTS `artist1nara`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artist1nara` (
  `date` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `event` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `sales` int(11) DEFAULT NULL,
  `salesvat` int(11) DEFAULT NULL,
  `etc` varchar(100) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artist1nara`
--

LOCK TABLES `artist1nara` WRITE;
/*!40000 ALTER TABLE `artist1nara` DISABLE KEYS */;
/*!40000 ALTER TABLE `artist1nara` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artist1twice`
--

DROP TABLE IF EXISTS `artist1twice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artist1twice` (
  `date` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `event` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `sales` int(11) DEFAULT NULL,
  `salesvat` int(11) DEFAULT NULL,
  `etc` varchar(100) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artist1twice`
--

LOCK TABLES `artist1twice` WRITE;
/*!40000 ALTER TABLE `artist1twice` DISABLE KEYS */;
/*!40000 ALTER TABLE `artist1twice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artist1zico`
--

DROP TABLE IF EXISTS `artist1zico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artist1zico` (
  `date` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `event` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `sales` int(11) DEFAULT NULL,
  `salesvat` int(11) DEFAULT NULL,
  `etc` varchar(100) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artist1zico`
--

LOCK TABLES `artist1zico` WRITE;
/*!40000 ALTER TABLE `artist1zico` DISABLE KEYS */;
/*!40000 ALTER TABLE `artist1zico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artist2bts`
--

DROP TABLE IF EXISTS `artist2bts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artist2bts` (
  `date` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `reason` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `cost` int(11) DEFAULT NULL,
  `costvat` int(11) DEFAULT NULL,
  `etc` varchar(100) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artist2bts`
--

LOCK TABLES `artist2bts` WRITE;
/*!40000 ALTER TABLE `artist2bts` DISABLE KEYS */;
INSERT INTO `artist2bts` VALUES ('20200318','x',7000,700,'tt'),('20200318','xx',5500,550,'889');
/*!40000 ALTER TABLE `artist2bts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artist2izone`
--

DROP TABLE IF EXISTS `artist2izone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artist2izone` (
  `date` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `reason` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `cost` int(11) DEFAULT NULL,
  `costvat` int(11) DEFAULT NULL,
  `etc` varchar(100) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artist2izone`
--

LOCK TABLES `artist2izone` WRITE;
/*!40000 ALTER TABLE `artist2izone` DISABLE KEYS */;
/*!40000 ALTER TABLE `artist2izone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artist2nara`
--

DROP TABLE IF EXISTS `artist2nara`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artist2nara` (
  `date` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `reason` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `cost` int(11) DEFAULT NULL,
  `costvat` int(11) DEFAULT NULL,
  `etc` varchar(100) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artist2nara`
--

LOCK TABLES `artist2nara` WRITE;
/*!40000 ALTER TABLE `artist2nara` DISABLE KEYS */;
/*!40000 ALTER TABLE `artist2nara` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artist2twice`
--

DROP TABLE IF EXISTS `artist2twice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artist2twice` (
  `date` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `reason` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `cost` int(11) DEFAULT NULL,
  `costvat` int(11) DEFAULT NULL,
  `etc` varchar(100) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artist2twice`
--

LOCK TABLES `artist2twice` WRITE;
/*!40000 ALTER TABLE `artist2twice` DISABLE KEYS */;
/*!40000 ALTER TABLE `artist2twice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artist2zico`
--

DROP TABLE IF EXISTS `artist2zico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artist2zico` (
  `date` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `reason` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `cost` int(11) DEFAULT NULL,
  `costvat` int(11) DEFAULT NULL,
  `etc` varchar(100) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artist2zico`
--

LOCK TABLES `artist2zico` WRITE;
/*!40000 ALTER TABLE `artist2zico` DISABLE KEYS */;
/*!40000 ALTER TABLE `artist2zico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `board` (
  `title` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES ('hello everyone','hoho','2020-03-17'),('nara love','hojae','2020-03-17'),('안뇽하세요','안뇽','2020-03-17'),('해볼께요','종료를','2020-03-17'),('테스트','종료','2020-03-17'),('1234','하잉','2020-03-17'),('ㅇㅇ','ㅇㅇ','2020-03-17'),('안뇽하세요','안뇽','2020-03-17');
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jpjlogin`
--

DROP TABLE IF EXISTS `jpjlogin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jpjlogin` (
  `id` varchar(100) DEFAULT NULL,
  `pw` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `part` varchar(100) DEFAULT NULL,
  `job` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  `number` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jpjlogin`
--

LOCK TABLES `jpjlogin` WRITE;
/*!40000 ALTER TABLE `jpjlogin` DISABLE KEYS */;
INSERT INTO `jpjlogin` VALUES ('park01','1234','park','9999','finance','ceo','20200306','2020030601'),('ggheon','1234','jiheon','010','Marketing','Intern','2020317','em1'),('hojae','1234','호재','010','Management','CEO','20200317','em2'),('ppp','1234','박','010','Management','Manager','2020-03-19','03197');
/*!40000 ALTER TABLE `jpjlogin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database '1stproject'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-19 16:30:46
