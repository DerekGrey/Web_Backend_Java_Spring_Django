package Board;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JList;

import BoardDB.BoardDAO;
import BoardDB.BoardDTO;
import pyh.Main;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class Board {
	static int count = 0;

	public void board() {
		JLabel like = new JLabel("");

		JFrame j = new JFrame();
		j.setTitle("대나무숲 매너~");
		j.setSize(774, 545);
		j.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("jpj Ent. 대나무숲");
		lblNewLabel.setFont(new Font("한컴산뜻돋움", Font.BOLD, 25));
		lblNewLabel.setBounds(274, 70, 225, 33);
		j.getContentPane().add(lblNewLabel);

		JButton btnNewButton_3 = new JButton("글쓰기");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// 글쓰기
				BoardWrite sign = new BoardWrite();
				sign.signIn();
				j.dispose();
				
			}
		});
		btnNewButton_3.setFont(new Font("한컴산뜻돋움", Font.BOLD, 15));
		btnNewButton_3.setBounds(580, 89, 141, 31);
		j.getContentPane().add(btnNewButton_3);

		like.setFont(new Font("굴림", Font.BOLD, 15));
		like.setBounds(715, 188, 84, 31);
		j.getContentPane().add(like);

		// dao사용 가져오기
		BoardDAO dao = new BoardDAO();
		ArrayList<BoardDTO> list = dao.all();

		// 목록갯수 찍어보기
		System.out.println(list.size());

		// 타이틀을 1차원 배열로 만들기
		Object[] title = { "내용", "닉네임", "날짜" };

		// 내용을 2차원 배열로 만들기
		Object[][] content = new Object[list.size()][];

		// for문 활용하여 내용 찍어주기
		for (int i = 0; i < list.size(); i++) {
			BoardDTO dto = list.get(i);

			// 배열의 값 나중에 넣어주는 경우
			Object[] row = new Object[3];
			row[0] = dto.getTitle();
			row[1] = dto.getName();
			row[2] = dto.getDate();
			content[i] = row;

			JTable table = new JTable(content, title);
			table.setRowHeight(40);
			table.getColumn("내용").setPreferredWidth(400);
			table.getColumn("닉네임").setPreferredWidth(5);
			table.getColumn("날짜").setPreferredWidth(5);

			
			
			JScrollPane s1 = new JScrollPane (table);
			s1.setBounds(50, 150, 600, 300);
			j.getContentPane().add(s1);
			j.setVisible(true);
			
			
		}
		j.setVisible(true);
	}

	


}
