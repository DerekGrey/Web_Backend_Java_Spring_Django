package Board;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;

import BoardDB.BoardDAO;
import BoardDB.BoardDTO;

import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;

public class BoardWrite {
	private static JTextField title;
	private static JTextField name;
	private static JTextField time2;
	
public void signIn() {
	
	SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
	Date time = new Date();
	String now = date.format(time);
	
			
	JFrame j = new JFrame();
	j.setTitle("jpj Ent. 대나무 숲입니다.");
	j.setSize(600, 355);
	j.getContentPane().setLayout(null);
	
	JLabel lblNewLabel = new JLabel("대나무숲 글쓰기");
	lblNewLabel.setFont(new Font("한컴산뜻돋움", Font.BOLD, 25));
	lblNewLabel.setBounds(198, 24, 205, 27);
	j.getContentPane().add(lblNewLabel);
	
	title = new JTextField();
	title.setFont(new Font("한컴산뜻돋움", Font.PLAIN, 15));
	title.setBounds(143, 123, 400, 37);
	j.getContentPane().add(title);
	title.setColumns(10);

	JLabel lblNewLabel_1 = new JLabel("한줄의견");
	lblNewLabel_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 15));
	lblNewLabel_1.setBounds(74, 131, 57, 21);
	j.getContentPane().add(lblNewLabel_1);
	
	JLabel lblNewLabel_1_1 = new JLabel("닉네임");
	lblNewLabel_1_1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 15));
	lblNewLabel_1_1.setBounds(74, 84, 57, 21);
	j.getContentPane().add(lblNewLabel_1_1);
	
	name = new JTextField();
	name.setFont(new Font("한컴산뜻돋움", Font.PLAIN, 15));
	name.setColumns(10);
	name.setBounds(143, 76, 147, 37);
	j.getContentPane().add(name);
	
	JLabel lblNewLabel_1_2 = new JLabel("게시시간");
	lblNewLabel_1_2.setFont(new Font("한컴산뜻돋움", Font.BOLD, 15));
	lblNewLabel_1_2.setBounds(74, 195, 57, 21);
	j.getContentPane().add(lblNewLabel_1_2);
	
	time2 = new JTextField();
	time2.setFont(new Font("한컴산뜻돋움", Font.PLAIN, 15));
	time2.setColumns(10);
	time2.setBounds(143, 187, 147, 37);
	j.getContentPane().add(time2);
	//현재시간 표시
	time2.setText(now);
	
	JButton save = new JButton("등록");
	save.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			//등록 버튼 눌렀을 때
			String wtitle = title.getText(); 
			String wname = name.getText(); 
			String wdate = time2.getText(); 
			
			//가방만들기
			BoardDTO dto = new BoardDTO();
			
			//가방에 넣기
			dto.setTitle(wtitle);
			dto.setName(wname);
			dto.setDate(wdate);
			
			//이동
			BoardDAO dao = new BoardDAO();
			dao.insert(dto);
			j.dispose();
			
			
			
		}
	});
	save.setBounds(232, 253, 113, 27);
	j.getContentPane().add(save);
	
	
	j.setVisible(true);
}


}
