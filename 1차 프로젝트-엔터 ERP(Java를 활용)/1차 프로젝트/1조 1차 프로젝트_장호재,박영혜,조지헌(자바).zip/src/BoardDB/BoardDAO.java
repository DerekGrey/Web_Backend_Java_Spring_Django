package BoardDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import Board.Board;


public class BoardDAO {

	String url = "jdbc:mysql://localhost:3708/1stproject?characterEncoding=utf8&serverTimezone=UTC";
	String user = "root";
	String password = "1234";

	
	//전체 검색
	public ArrayList<BoardDTO> all() { //타입 넣어주기
		ArrayList<BoardDTO> list = new ArrayList<>(); //만들어져야 보내니까 만들어야함!
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ㅇㅋ");

			// 2) DB연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. DB연결 ㅇㅋ");

			// 3) sql문 결정
			String sql = "select * from board"; // DB 의 ?만 1부터 시작함
			PreparedStatement ps = con.prepareStatement(sql);
			System.out.println("3. sql문 설정 ㅇㅋ..");

			// 4) sql문 전송
			ResultSet rs = ps.executeQuery(); // 셀렉만 다름. 반환값을 받아오는 애
			System.out.println("4.sql문 전송 ㅇㅋ");

			// 아이디 있는지 체크
			while(rs.next()) { // next 검색결과가 있는지 체크해주는 메소드, 여러개니까 while로 돌려줘야함
				               //next를 호출 할 때마다 row의 위치를 나타나내는 커서를 하나씩 아래로 옮기면서 그 해당 row가 있는지 체크해주는 메소드
							   //있으면 true, 없으면 false!
				System.out.println("검색결과가 있어요!!");
				BoardDTO dto2 = new BoardDTO();
				String title = rs.getString(1); // id (1) 또는 ("id") 이렇게 가져와도 됨.
				String name = rs.getString(2);
				String date = rs.getString(3);

				// 가져온거 창에 보내주기
				dto2.setTitle(title);
				dto2.setName(name);
				dto2.setDate(date);
				list.add(dto2); 
			}

		} catch (Exception e) { // 에러가 없음. exception 으로 모두 처리.
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list; // try 안에 있으면 안됨.
	}
	
	
	// 1. 의견 등록
	public void insert(BoardDTO dto) {
		System.out.println("의견등록 진행");
		try {
			// 1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 완료");

			// 2) DB연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. DB연결 ㅇㅋ");

			// 3) sql문 설정
			String sql = "insert into board values (?,?,?)"; // DB 의 ?만 1부터 시작함
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getTitle());
			ps.setString(2, dto.getName());
			ps.setString(3, dto.getDate());
			System.out.println("3. sql문 설정ㅇㅋ");
			
			// 4) sql문 전송
			ps.executeUpdate();
			System.out.println("4.sql문 전송 ㅇㅋ");
			JOptionPane.showMessageDialog(null, "의견등록 성공");
			Board sign = new Board();
			sign.board();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
